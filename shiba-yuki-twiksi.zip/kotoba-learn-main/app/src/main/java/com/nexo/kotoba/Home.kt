package com.nexo.kotoba

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar

@Composable
fun HomeScreen(
    store: Store,
    speaker: Speaker,
    modifier: Modifier = Modifier,
    onNav: (Screen) -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Text(
            if (store.target == "ja") "こんにちは！ 👋" else "Привет! 👋",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.secondary
        )
        Text(
            "Shiba Yuki",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            "Твой путь в японский язык",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold
        )
        Text(
            "Японский с нуля — понятно, постепенно и на русском",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(4.dp))
        Text(
            "создатель: Twiksi",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.secondary
        )
        Spacer(Modifier.height(12.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
        ) {
            Row(
                Modifier.fillMaxWidth().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("🐕", fontSize = 54.sp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Твой сиба-ину Юки", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    Text("Готов учиться? Пройдём следующий шаг вместе!", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        Spacer(Modifier.height(12.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
        ) {
            Row(
                Modifier.fillMaxWidth().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("あ", fontSize = 36.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Японская азбука", fontWeight = FontWeight.Bold)
                    Text("Хирагана и катакана — отдельный путь, не часть тематических уроков.", style = MaterialTheme.typography.bodySmall)
                }
                Button(onClick = { onNav(Screen.KANA) }) { Text("Открыть") }
            }
        }
        Spacer(Modifier.height(20.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(96.dp)) {
                    CircularProgressIndicator(
                        progress = { store.levelProgress() },
                        modifier = Modifier.size(96.dp),
                        strokeWidth = 10.dp,
                        strokeCap = StrokeCap.Round,
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.surface
                    )
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Ур. ${store.level()}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("${store.xp} XP", fontSize = 11.sp)
                    }
                }
                Spacer(Modifier.width(20.dp))
                Column {
                    Text(
                        "🔥 Серия: ${store.streak} дн.",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text("Лучший результат: ${store.bestStreak} дн.", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        if (store.streak == 0) "Начни сегодня — пусть серия растёт!"
                        else "Продолжай в том же духе — повтори несколько слов.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
        Spacer(Modifier.height(16.dp))

        val due = store.dueCount()
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(20.dp)) {
                Text("Продолжить обучение", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(
                    if (due > 0) "Для повторения готовы слова: $due."
                    else "Пока повторять нечего — время изучить что-нибудь новое!",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(14.dp))
                Button(onClick = { onNav(if (due > 0) Screen.REVIEW else Screen.LEARN) }) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(if (due > 0) "Повторить" else "Начать урок")
                }
            }
        }
        Spacer(Modifier.height(16.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("📚", "${store.wordsLearnedCount()}", "слов")
            StatCard("✅", "${store.completedLessons.size}", "уроков")
            StatCard("あ", "${store.learnedKana.size}", "знаков Kana")
        }
        Spacer(Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
        ) {
            Column(Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Filled.AutoAwesome,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.secondary
                    )
                    Spacer(Modifier.width(8.dp))
                    Text("Совет по обучению", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSecondaryContainer)
                }
                Spacer(Modifier.height(8.dp))
                Text(Tips.tipOfTheDay(), color = MaterialTheme.colorScheme.onSecondaryContainer)
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun RowScope.StatCard(emoji: String, value: String, label: String) {
    Card(
        modifier = Modifier.weight(1f),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(emoji, fontSize = 22.sp)
            Spacer(Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

object Tips {
    private val tips = listOf(
        "Повторение с интервалами помогает запоминать лучше, чем зубрёжка.",
        "Произноси слова вслух: слух и речь помогают запоминать.",
        "Связывай новые слова с образами — так их легче запомнить.",
        "Учи слова в готовых фразах — так быстрее начнёшь говорить.",
        "Пять минут повторения сегодня сэкономят время на следующей неделе.",
        "Первые сто слов помогут понимать множество повседневных фраз.",
        "Изучай кандзи внутри знакомых слов, а не только по отдельности.",
        "Ошибка — это подсказка, что стоит повторить.",
        "Повторяй сразу за диктором, стараясь передать ритм речи.",
        "Регулярность важнее длительности: занимайся хотя бы десять минут в день.",
        "Кана изучается отдельно от тематических уроков и открывает путь к чтению.",
        "Чередуй чтение, аудирование и речь — так знания закрепляются лучше."
    )

    fun tipOfTheDay(): String {
        val day = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        return tips[day % tips.size]
    }
}
