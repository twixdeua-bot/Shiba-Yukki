# Shiba Yuki — Japanese learning app by Twiksi

Android app for learning Japanese with a separate kana section, 26 themed chapters, 10 lessons per chapter, stories, dialogues, grammar, and a review list.

## Build

- JDK 17
- Android Gradle Plugin configured in the project
- Run `./gradlew assembleDebug`
- APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Lesson path and audio

- Each chapter has a winding, Duolingo-inspired path of 10 tappable lesson circles. Yuki marks the next unlocked lesson and moves to the next circle after a lesson is completed.
- Each lesson has 10 questions.
- Japanese speech uses the best-quality Japanese voice exposed by the Android text-to-speech engine, with a slightly slower pace and brighter pitch. The first speech request is queued until the engine initializes. If Japanese voice data is missing, the app opens Android's voice-data installer. Use Profile → “Проверить японскую озвучку” to test it.

## GitHub Actions

Upload this archive to the repository root as `shiba-yuki-twiksi.zip`, then run the `Build Shiba Yuki APK` workflow. Download the `shiba-yuki-twiksi-apk` artifact from the successful run.


## Обновление 4.2.0

- Главный экран сразу показывает путь текущей главы; отдельный переход в экран главы больше не нужен.
- Путь выстроен снизу вверх: первый урок находится внизу, следующие узлы выше. После завершения урока Юки анимированно перемещается к следующему узлу.
- Кнопки уроков получили объёмные градиенты, обводку и тени; добавлен новый иллюстрированный маскот Юки.
- Внутри каждого урока после третьего задания появляется тематический мини-диалог, после шестого — тематическая история из материалов соответствующей главы.
- Добавлены встроенные звуковые сигналы правильного/неправильного ответа и завершения урока. Они работают без скачивания.
- Исправлена инициализация системного TTS: она откладывается в очередь главного потока, проверяется результат установки японского языка и добавлен обработчик ошибок воспроизведения.

**Ограничение озвучки:** сигналы интерфейса встроены в APK, но динамическая японская речь пока использует TTS-движок Android. Это не то же самое, что полностью встроенная автономная нейросетевая японская озвучка; для неё потребуется включить в проект движок и языковую модель, что заметно увеличит APK. Поэтому на текущем этапе нельзя честно обещать, что произношение японских фраз будет работать на каждом телефоне без установленного японского голосового движка.

## Обновление 4.3.0 — система прогресса

- Учебный план использует 26 глав и 566 уроков; главы имеют разную длину в зависимости от темы (10–30 уроков), а не одинаковый фиксированный размер.
- Прогресс и XP сохраняются локально.
- Серия занятий засчитывается при завершении первого урока за день: продолжение серии требует занятия в следующий календарный день; пропуск дня сбрасывает серию при следующем завершённом уроке.
- Уровень Юки отображается рядом с прогрессом и растёт за XP (1 уровень за каждые 150 XP после стартового уровня).
- Добавлены достижения за 25 и 100 завершённых уроков.
- Слова из курса уже включаются в смешанные вопросы, а ошибки сохраняются в разделе повторения. Это локальная учебная система; автоматическая адаптация интервалов повторения ещё требует отдельного этапа.

## Проверка

JSON учебных материалов и структура архива проверяются локальными скриптами. Сборку APK следует считать подтверждённой только после успешного запуска GitHub Actions; локальная сборка может требовать доступа к загрузке Gradle.
