# Shiba Yuki — Japanese learning app by Twiksi

Android app for learning Japanese with a separate kana section, 26 themed chapters, 10 lessons per chapter, stories, dialogues, grammar, and a review list.

## Build

- JDK 17
- Android Gradle Plugin configured in the project
- Run `./gradlew assembleDebug`
- APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Lesson path and audio

- Each chapter has a winding, Duolingo-inspired path of 10 tappable lesson circles. Yuki marks the next unlocked lesson and moves to the next circle after a lesson is completed.
- Each lesson has 10 questions.
- Japanese speech uses the best-quality Japanese voice exposed by the Android text-to-speech engine, with a slightly slower pace and brighter pitch. The first speech request is queued until the engine initializes. If Japanese voice data is missing, the app opens Android's voice-data installer. Use Profile → “Проверить японскую озвучку” to test it.

## GitHub Actions

Upload this archive to the repository root as `shiba-yuki-twiksi.zip`, then run the `Build Shiba Yuki APK` workflow. Download the `shiba-yuki-twiksi-apk` artifact from the successful run.


## Обновление 4.2.0

- Главный экран сразу показывает путь текущей главы; отдельный переход в экран главы больше не нужен.
- Путь выстроен снизу вверх: первый урок находится внизу, следующие узлы выше. После завершения урока Юки анимированно перемещается к следующему узлу.
- Кнопки уроков получили объёмные градиенты, обводку и тени; добавлен новый иллюстрированный маскот Юки.
- Внутри каждого урока после третьего задания появляется тематический мини-диалог, после шестого — тематическая история из материалов соответствующей главы.
- Добавлены встроенные звуковые сигналы правильного/неправильного ответа и завершения урока. Они работают без скачивания.
- Исправлена инициализация системного TTS: она откладывается в очередь главного потока, проверяется результат установки японского языка и добавлен обработчик ошибок воспроизведения.

**Ограничение озвучки:** сигналы интерфейса встроены в APK, но динамическая японская речь пока использует TTS-движок Android. Это не то же самое, что полностью встроенная автономная нейросетевая японская озвучка; для неё потребуется включить в проект движок и языковую модель, что заметно увеличит APK. Поэтому на текущем этапе нельзя честно обещать, что произношение японских фраз будет работать на каждом телефоне без установленного японского голосового движка.

## Обновление 4.3.0 — система прогресса

- Учебный план использует 26 глав и 566 уроков; главы имеют разную длину в зависимости от темы (10–30 уроков), а не одинаковый фиксированный размер.
- Прогресс и XP сохраняются локально.
- Серия занятий засчитывается при завершении первого урока за день: продолжение серии требует занятия в следующий календарный день; пропуск дня сбрасывает серию при следующем завершённом уроке.
- Уровень Юки отображается рядом с прогрессом и растёт за XP (1 уровень за каждые 150 XP после стартового уровня).
- Добавлены достижения за 25 и 100 завершённых уроков.
- Слова из курса уже включаются в смешанные вопросы, а ошибки сохраняются в разделе повторения. Это локальная учебная система; автоматическая адаптация интервалов повторения ещё требует отдельного этапа.

## Проверка

JSON учебных материалов и структура архива проверяются локальными скриптами. Сборку APK следует считать подтверждённой только после успешного запуска GitHub Actions; локальная сборка может требовать доступа к загрузке Gradle.

## Yuki 3D companion — current implementation status

- `app/src/main/assets/models/yuki.glb` is bundled locally and loaded by SceneView; no network is required to fetch the model at runtime.
- `Yuki3DView` provides continuous idle motion and different motion rhythms for happy, curious/thinking, sad, and running states. Tapping Yuki in the lesson buddy card triggers a short interaction/reaction.
- `LessonWorld` selects a themed illustrated scene from the chapter/lesson title (city, hospital, park, home, shop, cafe, school, station, nature).
- These scene backdrops are currently stylized Compose illustrations, not fully modelled 3D environments.
- Important limitation: the bundled GLB currently has separate mesh parts but no authored skeletal animation clips/skin. Current reactions animate the rendered character viewport as a whole; independent paw/leg/tail/ear articulation, proper run cycle, sit, paw-shake, and emotion-specific facial rigs remain a separate asset/animation task. Do not describe this stage as a fully rigged animated 3D dog.

## Build

Run `./gradlew assembleDebug` with a working Gradle distribution/dependency connection. The current working environment could not reach `services.gradle.org`, so an APK build has not been verified here. Content verification scripts pass.

## Voice-first dialogue update

The conversation screen is now voice-first: it no longer presents multiple-choice answer buttons. Learners speak Japanese into Android's speech-recognition activity, and the app checks the recognized phrase against accepted phrases stored in the dialogue data. The expected choices remain hidden. This is a useful offline-app integration point, but recognition availability/language support depends on the device's installed speech-recognition service; this is not yet an open-ended LLM conversation or a phonetic pronunciation-scoring engine.

Story beats remain gated: the learner must listen to the Japanese audio segment and explicitly open the comprehension question before any answer choices appear. After answering, the next story segment becomes available.

Yuki's trail greeting now reflects time since the last completed lesson: after a day away he says he is glad the learner returned; after three or more days he says he missed them; recent activity produces a happy greeting. This is a lightweight supportive mood indicator, not a guilt/punishment mechanic.
