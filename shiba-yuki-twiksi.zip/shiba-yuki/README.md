# Shiba Yuki — Japanese learning app by Twiksi

Android app for learning Japanese with a separate kana section, 26 themed chapters, 10 lessons per chapter, stories, dialogues, grammar, and a review list.

## Build

- JDK 17
- Android Gradle Plugin configured in the project
- Run `./gradlew assembleDebug`
- APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Lesson path and audio

- Each chapter has a winding, Duolingo-inspired path of 10 tappable lesson circles. Yuki marks the next unlocked lesson and moves to the next circle after a lesson is completed.
- Each lesson has 10 questions.
- Japanese speech uses the best-quality Japanese voice exposed by the Android text-to-speech engine, with a slightly slower pace and brighter pitch. The first speech request is queued until the engine initializes. If Japanese voice data is missing, the app opens Android's voice-data installer. Use Profile → “Проверить японскую озвучку” to test it.

## GitHub Actions

Upload this archive to the repository root as `shiba-yuki-twiksi.zip`, then run the `Build Shiba Yuki APK` workflow. Download the `shiba-yuki-twiksi-apk` artifact from the successful run.
