# Shiba Yuki 4.4 — review notes

## Changes in this package
- Centralized Material 3 color palette with cream background, ink text, green primary, peach/orange secondary, purple accent, and softer rounded component shapes.
- Bottom navigation now has a slightly elevated, rounded top edge.
- Lesson distractors now prioritize vocabulary from the same chapter before falling back to the wider course pool.
- Version set to 4.4.0 / versionCode 36.

## Content inventory checked
- 26 chapters
- 566 standard lessons
- 26 stories / 78 story beats
- 52 dialogues / 156 dialogue turns
- 34 grammar rules
- Existing content verification scripts pass.

## Known issues not to mistake as finished
- Stories/dialogues are still accessible through their own screens and the current lesson flow still contains interlude logic; the desired mixed standalone path nodes are not yet fully refactored.
- The curriculum count/content checks confirm structure, not pedagogical correctness of every Japanese phrase. A full native-speaker/teacher review is still needed, especially for nuance, politeness levels, and romaji consistency.
- Yuki's bundled GLB is not a fully rigged skeletal character with authored independent animation clips. Do not market it as such.
- Japanese speech depends on the Android TTS voice/service; it is not a fully bundled offline Japanese voice model.
- Cloud account/progress sync is intentionally not included at this stage.
- The proposed “Check my knowledge” diagnostic feature is not yet implemented in this package.

## Build status
The source-level content scripts pass. APK build was attempted with `./gradlew assembleDebug`, but the environment cannot resolve `services.gradle.org` to download Gradle 8.7, so no APK was produced or verified here.
