# Build fix notes

- Explicitly align Compose animation artifacts to 1.7.2, matching Compose BOM 2024.09.00.
- Declare the BOM before Compose dependencies.
- This targets the reported unresolved `InfiniteTransition.animateFloat` symbol.

Important: this source archive has not been successfully built in this environment because Gradle distribution access is blocked by DNS/network restrictions. A green GitHub Actions build is still required to certify the APK.
