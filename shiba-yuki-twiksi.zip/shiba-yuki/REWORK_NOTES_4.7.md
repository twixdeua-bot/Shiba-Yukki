# Shiba Yuki 4.7 rework

- Restored the real SceneView/Filament GLB renderer for `models/yuki.glb`; the companion is no longer only a PNG.
- Raised Android toolchain to AGP 8.13.2 / Gradle 8.13 / Kotlin 2.2.21 and compileSdk 37 for SceneView 4.57.0 metadata.
- Reworked lesson interludes so story and dialogue segments ask a real multiple-choice comprehension/response question; correct responses trigger the next lesson step automatically.
- Removed developer QA shortcut buttons and the standalone Story button from the chapter screen. Stories are surfaced inside lesson progression.
- Shifted base palette toward warm shiba cream, fox orange and brown.

This source has been statically checked and packaged; a successful CI APK build is still required to validate the complete Android toolchain and native SceneView integration.
