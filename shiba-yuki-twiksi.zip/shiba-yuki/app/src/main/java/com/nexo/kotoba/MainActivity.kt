package com.nexo.kotoba

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

enum class Screen { HOME, LEARN, KANA, REVIEW, GRAMMAR, DICTIONARY, PROFILE }

private val Ink = Color(0xFF253044)
private val Muted = Color(0xFF7B8798)
private val Cream = Color(0xFFFFFBF5)
private val Paper = Color(0xFFFFFFFF)
private val Green = Color(0xFF58B878)
private val GreenDark = Color(0xFF318A57)
private val Mint = Color(0xFFE8F7EC)
private val Orange = Color(0xFFFFA64D)
private val Peach = Color(0xFFFFE8D6)
private val Purple = Color(0xFF8876E8)
private val Lavender = Color(0xFFF0EDFF)
private val Blue = Color(0xFF63B6E8)
private val Line = Color(0xFFE8E7E1)

private enum class YukiTab(val title: String) { PATH("Путь"), KANA("Азбука"), WORDS("Слова"), PROFILE("Профиль") }
private enum class YukiPage { MAIN, LESSON, KANA, WORDS, PROFILE, REVIEW, GRAMMAR }
private data class Lesson(val id: Int, val title: String, val subtitle: String, val chapter: Int, val xp: Int = 10, val items: List<QuizItem>)
private data class QuizItem(val prompt: String, val hint: String, val choices: List<String>, val answer: String, val explain: String)
private data class Chapter(val id: Int, val title: String, val subtitle: String, val color: Color, val icon: String)

private val chapters = listOf(
    Chapter(1, "Первые шаги", "Приветствия и знакомство", Green, "🌱"),
    Chapter(2, "Моя жизнь", "Люди, вещи и повседневность", Orange, "🏡"),
    Chapter(3, "Время и места", "Часы, направления и планы", Purple, "🗺️"),
    Chapter(4, "Японский каждый день", "Еда, покупки и разговоры", Blue, "🍡")
)
private val lessons = listOf(
    Lesson(1,"Привет!","Первые японские слова",1, items=listOf(
        QuizItem("Как сказать «привет»?","Выбери японское приветствие.", listOf("こんにちは","さようなら","ありがとう","すみません"),"こんにちは","Конничива — привет / здравствуйте днём."),
        QuizItem("ありがとう","Что означает это слово?",listOf("Извините","Спасибо","Пока","Доброе утро"),"Спасибо","Аригато: спасибо."),
        QuizItem("Выбери запись «сумимасэн»","Это вежливое «извините».",listOf("すみません","おはよう","こんばんは","はい"),"すみません","Сумимасэн используют, чтобы извиниться или привлечь внимание."))),
    Lesson(2,"Знакомство","Как представиться",1, items=listOf(
        QuizItem("わたし","Переведи слово.",listOf("Ты","Я","Друг","Учитель"),"Я","Ватаси — я."),
        QuizItem("わたしはアナです。","Что означает предложение?",listOf("Я Анна.","Ты Анна?","Это книга.","Я дома."),"Я Анна.","Шаблон: ватаси ва [имя] дэсу — я [имя]."),
        QuizItem("Как спросить «Вы Анна?»","Выбери вопрос.",listOf("アナですか。","アナじゃない。","ありがとう。","さようなら。"),"アナですか。","Частица ка в конце превращает фразу в вопрос."))),
    Lesson(3,"Да и нет","Простые ответы",1, items=listOf(
        QuizItem("はい","Что это?",listOf("Нет","Да","Спасибо","Пожалуйста"),"Да","Хай — да."),
        QuizItem("いいえ","Что это?",listOf("Да","Привет","Нет","Пока"),"Нет","Ииэ — нет."),
        QuizItem("いいえ、ちがいます。","Выбери перевод.",listOf("Нет, это не так.","Да, спасибо.","Доброе утро.","Я студент."),"Нет, это не так.","Тигаимас — «не так / ошибаетесь»."))),
    Lesson(4,"Моя семья","Люди рядом",2, items=listOf(
        QuizItem("ともだち","Переведи.",listOf("Семья","Друг","Мама","Дом"),"Друг","Томодачи — друг / друзья."),
        QuizItem("はは","Как сказать «моя мама»?",listOf("はは","ちち","ともだち","せんせい"),"はは","Хаха — моя мама (о своей семье)."),
        QuizItem("せんせい","Кто это?",listOf("Учитель","Ученик","Друг","Брат"),"Учитель","Сэнсэй — учитель, преподаватель."))),
    Lesson(5,"Вокруг меня","Предметы и указатели",2, items=listOf(
        QuizItem("ほん","Переведи.",listOf("Книга","Стол","Телефон","Вода"),"Книга","Хон — книга."),
        QuizItem("これはなんですか。","Что спрашивают?",listOf("Что это?","Где ты?","Который час?","Кто это?"),"Что это?","Корэ ва нан дэсу ка — что это?"),
        QuizItem("みず","Что означает слово?",listOf("Еда","Вода","Чай","Молоко"),"Вода","Мидзу — вода."))),
    Lesson(6,"Что я люблю","Вкусы и интересы",2, items=listOf(
        QuizItem("すきです","Что означает?",listOf("Мне нравится","Я не знаю","Я устал","Я читаю"),"Мне нравится","Суки дэсу — нравится / люблю."),
        QuizItem("ねこ","Кто это?",listOf("Собака","Кошка","Птица","Рыба"),"Кошка","Нэко — кошка."),
        QuizItem("いぬ","Кто это?",listOf("Кошка","Собака","Лошадь","Медведь"),"Собака","Ину — собака."))),
    Lesson(7,"Который час?","Время и числа",3, items=listOf(
        QuizItem("いまなんじですか。","Что означает?",listOf("Который сейчас час?","Где станция?","Как тебя зовут?","Что это?"),"Который сейчас час?","Има нан-дзи дэсу ка — который сейчас час?"),
        QuizItem("いち","Какое это число?",listOf("Один","Два","Три","Четыре"),"Один","Ити — один."),
        QuizItem("ごじ","Который час?",listOf("Пять часов","Пять минут","Пять дней","Пять лет"),"Пять часов","Го-дзи — пять часов."))),
    Lesson(8,"Где это?","Места и направления",3, items=listOf(
        QuizItem("えき","Переведи.",listOf("Станция","Школа","Магазин","Парк"),"Станция","Эки — станция."),
        QuizItem("どこ","Что означает?",listOf("Когда","Почему","Где","Кто"),"Где","Доко — где."),
        QuizItem("トイレはどこですか。","Что ты спрашиваешь?",listOf("Где туалет?","Где вокзал?","Что это?","Сколько стоит?"),"Где туалет?","Тойрэ ва доко дэсу ка — где туалет?"))),
    Lesson(9,"Еда и напитки","Заказываем в кафе",4, items=listOf(
        QuizItem("みずをください。","Что ты просишь?",listOf("Воды, пожалуйста.","Счёт, пожалуйста.","Кофе, пожалуйста.","Меню, пожалуйста."),"Воды, пожалуйста.","Мидзу о кудасай — воды, пожалуйста."),
        QuizItem("おいしい","Переведи.",listOf("Вкусно","Горячо","Дорого","Большой"),"Вкусно","Ойсии — вкусно."),
        QuizItem("コーヒー","Что это?",listOf("Чай","Кофе","Вода","Сок"),"Кофе","Катакана часто используется для заимствованных слов."))),
    Lesson(10,"Закрепление","Проверь, что запомнил",4, items=listOf(
        QuizItem("おはようございます","Когда это говорят?",listOf("Доброе утро","Спокойной ночи","Спасибо","До свидания"),"Доброе утро","Охаё годзаимас — вежливое «доброе утро»."),
        QuizItem("ほんをよみます。","Выбери перевод.",listOf("Я читаю книгу.","Я смотрю фильм.","Я пью воду.","Я иду домой."),"Я читаю книгу.","Хон о ёмимас — читаю книгу."),
        QuizItem("またね","Что это?",listOf("Увидимся!","Извините","Спасибо","Я не понимаю"),"Увидимся!","Мата нэ — до встречи, увидимся.")))
)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(255,251,245)
        window.navigationBarColor = android.graphics.Color.rgb(255,251,245)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        tts = TextToSpeech(this) { status -> if (status == TextToSpeech.SUCCESS) tts?.language = Locale.JAPAN }
        setContent { ShibaYukiApp(onSpeak = { speak(it) }) }
    }
    private fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "yuki-${System.currentTimeMillis()}") }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

@Composable
private fun ShibaYukiApp(onSpeak: (String) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("shiba_yuki_progress", android.content.Context.MODE_PRIVATE) }
    var xp by remember { mutableIntStateOf(prefs.getInt("xp", 0)) }
    var completed by remember { mutableStateOf(prefs.getStringSet("completed", emptySet())?.toSet() ?: emptySet()) }
    var streak by remember { mutableIntStateOf(prefs.getInt("streak", 1)) }
    var tab by remember { mutableStateOf(YukiTab.PATH) }
    var page by remember { mutableStateOf(YukiPage.MAIN) }
    var selectedLesson by remember { mutableStateOf<Lesson?>(null) }
    var lessonIndex by remember { mutableIntStateOf(0) }
    var selectedKana by remember { mutableStateOf("ひらがな") }
    val haptics = LocalHapticFeedback.current

    fun saveProgress(newXp: Int, newCompleted: Set<String>) {
        xp = newXp; completed = newCompleted
        prefs.edit().putInt("xp", newXp).putStringSet("completed", newCompleted).putInt("streak", streak).apply()
    }
    fun openTab(newTab: YukiTab) { tab = newTab; page = when(newTab) { YukiTab.PATH -> YukiPage.MAIN; YukiTab.KANA -> YukiPage.KANA; YukiTab.WORDS -> YukiPage.WORDS; YukiTab.PROFILE -> YukiPage.PROFILE } }
    BackHandler(enabled = page != YukiPage.MAIN) {
        if (page == YukiPage.LESSON) { page = YukiPage.MAIN; selectedLesson = null } else page = YukiPage.MAIN
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = GreenDark, onPrimary = Color.White, background = Cream, surface = Paper, onSurface = Ink, secondary = Orange)) {
        Scaffold(containerColor = Cream, bottomBar = {
            if (page != YukiPage.LESSON) NavigationBar(containerColor = Paper, tonalElevation = 0.dp, windowInsets = NavigationBarDefaults.windowInsets) {
                listOf(YukiTab.PATH, YukiTab.KANA, YukiTab.WORDS, YukiTab.PROFILE).forEach { item ->
                    NavigationBarItem(selected = tab == item, onClick = { openTab(item) }, icon = {
                        val ico = when(item) { YukiTab.PATH -> Icons.Filled.Explore; YukiTab.KANA -> Icons.Filled.AutoStories; YukiTab.WORDS -> Icons.Filled.MenuBook; YukiTab.PROFILE -> Icons.Filled.School }
                        Icon(ico, null, modifier = Modifier.size(23.dp))
                    }, label = { Text(item.title, fontSize = 11.sp, fontWeight = if (tab == item) FontWeight.Bold else FontWeight.Medium) }, alwaysShowLabel = true, colors = NavigationBarItemDefaults.colors(selectedIconColor = GreenDark, selectedTextColor = GreenDark, indicatorColor = Mint, unselectedIconColor = Muted, unselectedTextColor = Muted))
                }
            }
        }) { inner ->
            AnimatedContent(targetState = page, modifier = Modifier.padding(inner), transitionSpec = { (fadeIn() + slideInHorizontally { it / 18 }) togetherWith (fadeOut() + slideOutHorizontally { -it / 18 }) }, label = "page") { current ->
                when(current) {
                    YukiPage.MAIN -> PathPage(xp, completed, streak, onLesson = { lesson -> selectedLesson = lesson; lessonIndex = 0; page = YukiPage.LESSON }, onKana = { openTab(YukiTab.KANA) }, onReview = { page = YukiPage.REVIEW }, onGrammar = { page = YukiPage.GRAMMAR })
                    YukiPage.KANA -> KanaPage(selectedKana, { selectedKana = it }, onSpeak)
                    YukiPage.WORDS -> WordsPage(onSpeak)
                    YukiPage.PROFILE -> ProfilePage(xp, completed.size, streak)
                    YukiPage.REVIEW -> ReviewPage(onSpeak, onBack = { page = YukiPage.MAIN })
                    YukiPage.GRAMMAR -> GrammarPage(onBack = { page = YukiPage.MAIN })
                    YukiPage.LESSON -> selectedLesson?.let { lesson -> LessonPage(lesson, lessonIndex, onIndex = { lessonIndex = it }, onSpeak = onSpeak, onExit = { page = YukiPage.MAIN; selectedLesson = null }, onFinish = { earned ->
                        val next = completed + lesson.id.toString(); saveProgress(xp + earned, next); haptics.performHapticFeedback(HapticFeedbackType.LongPress); page = YukiPage.MAIN; selectedLesson = null
                    }) }
                }
            }
        }
    }
}

@Composable
private fun PathPage(xp: Int, completed: Set<String>, streak: Int, onLesson: (Lesson) -> Unit, onKana: () -> Unit, onReview: () -> Unit, onGrammar: () -> Unit) {
    val progress = completed.size.toFloat() / lessons.size
    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 16.dp, bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("SHIBA YUKI", fontSize = 12.sp, color = GreenDark, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp); Text("Привет, ученик!", fontSize = 25.sp, color = Ink, fontWeight = FontWeight.ExtraBold) }
            StatPill("🔥", streak.toString()); Spacer(Modifier.width(8.dp)); StatPill("⚡", xp.toString())
        } }
        item { HeroCard(progress, completed.size, onLesson = { onLesson(lessons.firstOrNull { it.id.toString() !in completed } ?: lessons.last()) }) }
        item { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text("Твой путь", fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, color = Ink, modifier = Modifier.weight(1f)); Text("${completed.size}/${lessons.size} уроков", fontSize = 12.sp, color = Muted, fontWeight = FontWeight.SemiBold) } }
        items(chapters) { chapter ->
            val chapterLessons = lessons.filter { it.chapter == chapter.id }
            val doneInChapter = chapterLessons.count { it.id.toString() in completed }
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Paper).padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).background(chapter.color.copy(alpha = .14f)), contentAlignment = Alignment.Center) { Text(chapter.icon, fontSize = 24.sp) }
                    Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text("ГЛАВА ${chapter.id}", fontSize = 10.sp, color = chapter.color, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.4.sp); Text(chapter.title, fontSize = 18.sp, color = Ink, fontWeight = FontWeight.Bold); Text(chapter.subtitle, fontSize = 12.sp, color = Muted) }
                    Text("$doneInChapter/${chapterLessons.size}", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(13.dp))
                Box(Modifier.fillMaxWidth().height(5.dp).clip(CircleShape).background(Line)) { Box(Modifier.fillMaxWidth(if (chapterLessons.isEmpty()) 0f else doneInChapter.toFloat()/chapterLessons.size).fillMaxHeight().clip(CircleShape).background(chapter.color)) }
                Spacer(Modifier.height(12.dp))
                chapterLessons.forEachIndexed { index, lesson ->
                    val isDone = lesson.id.toString() in completed
                    val unlocked = lesson.id == 1 || (lesson.id - 1).toString() in completed || isDone
                    LessonNode(lesson = lesson, number = index + 1, done = isDone, unlocked = unlocked, tint = chapter.color, onClick = { if (unlocked) onLesson(lesson) })
                    if (index != chapterLessons.lastIndex) Spacer(Modifier.height(8.dp))
                }
            }
        }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MiniAction("🔤", "Азбука", "Хирагана и катакана", Modifier.weight(1f), onKana)
            MiniAction("🧠", "Повторение", "Закрепи слова", Modifier.weight(1f), onReview)
        } }
        item { MiniAction("📘", "Грамматика", "Разбирайся в правилах", Modifier.fillMaxWidth(), onGrammar) }
        item { Text("Сделано с заботой • Twiksi", Modifier.fillMaxWidth(), color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center) }
    }
}

@Composable private fun HeroCard(progress: Float, done: Int, onLesson: () -> Unit) {
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Brush.linearGradient(listOf(Color(0xFF287D52), Color(0xFF66BE82)))).padding(20.dp)) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("ЯПОНСКИЙ С НУЛЯ", color = Color.White.copy(.8f), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.4.sp); Spacer(Modifier.height(6.dp)); Text("Маленькие шаги —\nбольшой прогресс", color = Color.White, fontSize = 23.sp, lineHeight = 28.sp, fontWeight = FontWeight.ExtraBold) }
                Mascot(size = 88)
            }
            Spacer(Modifier.height(12.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.weight(1f).height(7.dp).clip(CircleShape).background(Color.White.copy(.25f))) { Box(Modifier.fillMaxWidth(progress.coerceIn(0f,1f)).fillMaxHeight().clip(CircleShape).background(Color.White)) }; Spacer(Modifier.width(10.dp)); Text("${(progress*100).toInt()}%", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
            Spacer(Modifier.height(7.dp)); Text("Уроков пройдено: $done из ${lessons.size}", color = Color.White.copy(.85f), fontSize = 12.sp)
            Spacer(Modifier.height(15.dp)); Button(onClick = onLesson, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = GreenDark), shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth().height(48.dp)) { Text("Продолжить обучение", fontWeight = FontWeight.ExtraBold); Spacer(Modifier.width(6.dp)); Icon(Icons.Filled.ChevronRight, null) }
        }
    }
}

@Composable private fun Mascot(size: Int) {
    val bob by androidx.compose.animation.core.animateFloatAsState(targetValue = 1f, animationSpec = spring(dampingRatio = .5f, stiffness = 90f), label = "mascot")
    Box(Modifier.size(size.dp).scale(bob).clip(CircleShape).background(Color.White.copy(.16f)), contentAlignment = Alignment.Center) {
        Text("🐕", fontSize = (size*.55).sp)
    }
}

@Composable private fun StatPill(icon: String, value: String) { Row(Modifier.clip(RoundedCornerShape(14.dp)).background(Paper).padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { Text(icon, fontSize = 15.sp); Spacer(Modifier.width(4.dp)); Text(value, fontWeight = FontWeight.ExtraBold, color = Ink, fontSize = 13.sp) } }

@Composable private fun LessonNode(lesson: Lesson, number: Int, done: Boolean, unlocked: Boolean, tint: Color, onClick: () -> Unit) {
    val scale by animateFloatAsState(if (done) 1.02f else 1f, label = "nodeScale")
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(if (done) tint.copy(.08f) else Cream).clickable(enabled = unlocked, onClick = onClick).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(43.dp).scale(scale).clip(CircleShape).background(when { done -> tint; unlocked -> tint.copy(.14f); else -> Line }), contentAlignment = Alignment.Center) {
            if (done) Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.size(23.dp)) else if (!unlocked) Icon(Icons.Filled.Lock, null, tint = Muted, modifier = Modifier.size(19.dp)) else Text(number.toString(), color = tint, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
        }
        Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(lesson.title, fontWeight = FontWeight.Bold, color = if (unlocked) Ink else Muted, fontSize = 15.sp); Text(lesson.subtitle, fontSize = 11.sp, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis) }
        Text(if (done) "Пройдено" else if (unlocked) "+${lesson.xp} XP" else "Закрыт", color = if (done) tint else Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable private fun MiniAction(emoji: String, title: String, subtitle: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Row(modifier.clip(RoundedCornerShape(19.dp)).background(Paper).clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(emoji, fontSize = 25.sp); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(title, color = Ink, fontSize = 14.sp, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, fontSize = 10.sp, lineHeight = 13.sp) }; Icon(Icons.Filled.ChevronRight, null, tint = Muted, modifier = Modifier.size(18.dp))
    }
}

@Composable private fun LessonPage(lesson: Lesson, index: Int, onIndex: (Int) -> Unit, onSpeak: (String) -> Unit, onExit: () -> Unit, onFinish: (Int) -> Unit) {
    var selected by remember(lesson.id, index) { mutableStateOf<String?>(null) }
    var checked by remember(lesson.id, index) { mutableStateOf(false) }
    val question = lesson.items[index]
    val correct = selected == question.answer
    val progress = (index + if (checked) 1 else 0).toFloat() / lesson.items.size
    Column(Modifier.fillMaxSize().background(Cream).padding(horizontal = 20.dp, vertical = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onExit) { Icon(Icons.Filled.Close, "Выйти из урока", tint = Muted) }; Spacer(Modifier.width(7.dp)); Box(Modifier.weight(1f).height(9.dp).clip(CircleShape).background(Line)) { Box(Modifier.fillMaxWidth(progress.coerceIn(.03f,1f)).fillMaxHeight().clip(CircleShape).background(Green)) }; Spacer(Modifier.width(12.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Filled.Favorite, null, tint = Color(0xFFEF6A73), modifier = Modifier.size(18.dp)); Text(" 5", color = Ink, fontWeight = FontWeight.Bold) } }
        Spacer(Modifier.height(22.dp)); Text("${lesson.title.uppercase()} • ${index+1} ИЗ ${lesson.items.size}", color = GreenDark, fontSize = 11.sp, letterSpacing = 1.1.sp, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.height(10.dp)); Text(question.prompt, color = Ink, fontSize = 26.sp, lineHeight = 32.sp, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.height(8.dp)); Text(question.hint, color = Muted, fontSize = 14.sp)
        Spacer(Modifier.height(25.dp))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(11.dp)) {
            question.choices.forEachIndexed { i, choice ->
                val isPicked = selected == choice
                val showRight = checked && choice == question.answer
                val showWrong = checked && isPicked && !correct
                val border = when { showRight -> Green; showWrong -> Color(0xFFE66E75); isPicked -> GreenDark; else -> Line }
                val bg = when { showRight -> Mint; showWrong -> Color(0xFFFFE8E8); isPicked -> Mint; else -> Paper }
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(bg).clickable(enabled = !checked) { selected = choice }.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(28.dp).clip(RoundedCornerShape(9.dp)).background(if (isPicked || showRight) border else Cream), contentAlignment = Alignment.Center) { if (showRight) Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.size(17.dp)) else Text("${'А'+i}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (isPicked) Color.White else Muted) }
                    Spacer(Modifier.width(12.dp)); Text(choice, color = Ink, fontWeight = if (isPicked || showRight) FontWeight.Bold else FontWeight.Medium, fontSize = 16.sp, modifier = Modifier.weight(1f)); if (showRight || showWrong) Text(if (showRight) "✓" else "×", color = border, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                }
                if (isPicked || showRight || showWrong) Spacer(Modifier.height(0.dp))
            }
        }
        AnimatedVisibility(visible = checked) { Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(if (correct) Mint else Peach).padding(14.dp)) { Text(if (correct) "Отлично! 🎉" else "Почти! Давай запомним", fontWeight = FontWeight.ExtraBold, color = if (correct) GreenDark else Color(0xFF9C5A20), fontSize = 16.sp); Spacer(Modifier.height(4.dp)); Text(question.explain, color = Ink, fontSize = 13.sp); Row(verticalAlignment = Alignment.CenterVertically) { Text("Послушать", color = GreenDark, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { onSpeak(question.prompt) }.padding(top = 8.dp)); Icon(Icons.Filled.VolumeUp, null, tint = GreenDark, modifier = Modifier.padding(start = 4.dp, top = 8.dp).size(16.dp)) } } }
        Spacer(Modifier.height(12.dp))
        Button(onClick = { if (!checked) { if (selected != null) checked = true } else if (index < lesson.items.lastIndex) onIndex(index + 1) else onFinish(lesson.xp) }, enabled = if (!checked) selected != null else true, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(17.dp), colors = ButtonDefaults.buttonColors(containerColor = if (checked) GreenDark else Green, disabledContainerColor = Color(0xFFCAD5CC))) { Text(if (!checked) "Проверить ответ" else if (index == lesson.items.lastIndex) "Завершить урок" else "Продолжить", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold) }
    }
}

private val hira = listOf("あ" to "а","い" to "и","う" to "у","え" to "э","お" to "о","か" to "ка","き" to "ки","く" to "ку","け" to "кэ","こ" to "ко","さ" to "са","し" to "си","す" to "су","せ" to "сэ","そ" to "со","た" to "та","ち" to "ти","つ" to "цу","て" to "тэ","と" to "то","な" to "на","に" to "ни","ぬ" to "ну","ね" to "нэ","の" to "но","は" to "ха","ひ" to "хи","ふ" to "фу","へ" to "хэ","ほ" to "хо","ま" to "ма","み" to "ми","む" to "му","め" to "мэ","も" to "мо","や" to "я","ゆ" to "ю","よ" to "ё","ら" to "ра","り" to "ри","る" to "ру","れ" to "рэ","ろ" to "ро","わ" to "ва","を" to "о","ん" to "н")
private val kata = listOf("ア" to "а","イ" to "и","ウ" to "у","エ" to "э","オ" to "о","カ" to "ка","キ" to "ки","ク" to "ку","ケ" to "кэ","コ" to "ко","サ" to "са","シ" to "си","ス" to "су","セ" to "сэ","ソ" to "со","タ" to "та","チ" to "ти","ツ" to "цу","テ" to "тэ","ト" to "то","ナ" to "на","ニ" to "ни","ヌ" to "ну","ネ" to "нэ","ノ" to "но","ハ" to "ха","ヒ" to "хи","フ" to "фу","ヘ" to "хэ","ホ" to "хо","マ" to "ма","ミ" to "ми","ム" to "му","メ" to "мэ","モ" to "мо","ヤ" to "я","ユ" to "ю","ヨ" to "ё","ラ" to "ра","リ" to "ри","ル" to "ру","レ" to "рэ","ロ" to "ро","ワ" to "ва","ヲ" to "о","ン" to "н")

@Composable private fun KanaPage(selected: String, onSelect: (String) -> Unit, onSpeak: (String) -> Unit) {
    val chars = if (selected == "ひらがな") hira else kata
    var practice by remember { mutableStateOf(false) }
    var cardIndex by remember { mutableIntStateOf(0) }
    var reveal by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Text("ОТДЕЛЬНЫЙ МАРШРУТ", color = GreenDark, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp); Text("Японская азбука", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = Ink); Text("Учи знаки в своём темпе — отдельно от уроков.", fontSize = 13.sp, color = Muted)
        Spacer(Modifier.height(18.dp)); Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Line).padding(4.dp)) { listOf("ひらがな","カタカナ").forEach { label -> Box(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(if (selected == label) Paper else Color.Transparent).clickable { onSelect(label); cardIndex = 0; reveal = false }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) { Text(if (label == "ひらがな") "Хирагана" else "Катакана", fontWeight = FontWeight.Bold, color = if (selected == label) GreenDark else Muted) } } }
        Spacer(Modifier.height(16.dp)); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { InfoChip("${chars.size} знаков"); InfoChip("Основной ряд"); InfoChip("Ромадзи") }
        Spacer(Modifier.height(16.dp)); if (practice) {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Paper).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("КАРТОЧКА ${cardIndex+1} ИЗ ${chars.size}", color = Muted, fontWeight = FontWeight.Bold, fontSize = 11.sp); Spacer(Modifier.height(18.dp)); Text(chars[cardIndex].first, fontSize = 76.sp, color = Ink, fontWeight = FontWeight.Medium); if (reveal) Text(chars[cardIndex].second, fontSize = 24.sp, color = GreenDark, fontWeight = FontWeight.Bold) else Text("Вспомни произношение", color = Muted, fontSize = 13.sp); Spacer(Modifier.height(20.dp)); Button(onClick = { reveal = !reveal }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text(if (reveal) "Скрыть ответ" else "Показать ответ") }; Spacer(Modifier.height(8.dp)); OutlinedButton(onClick = { onSpeak(chars[cardIndex].first) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Icon(Icons.Filled.VolumeUp, null); Spacer(Modifier.width(8.dp)); Text("Послушать") }; Spacer(Modifier.height(12.dp)); Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { OutlinedButton(onClick = { cardIndex = (cardIndex - 1 + chars.size) % chars.size; reveal = false }, modifier = Modifier.weight(1f)) { Text("Назад") }; Button(onClick = { cardIndex = (cardIndex + 1) % chars.size; reveal = false }, modifier = Modifier.weight(1f)) { Text("Дальше →") } }
            }; Spacer(Modifier.height(10.dp)); TextButton(onClick = { practice = false }) { Text("Вернуться к таблице") }
        } else {
            Button(onClick = { practice = true; cardIndex = 0; reveal = false }, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(15.dp)) { Text("Начать тренировку карточками", fontWeight = FontWeight.Bold) }
            Spacer(Modifier.height(16.dp)); Text("Знаки и произношение", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.height(10.dp))
            val rows = chars.chunked(5)
            rows.forEach { row -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) { row.forEach { (symbol, reading) -> Column(Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(Paper).clickable { onSpeak(symbol) }.padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(symbol, color = Ink, fontSize = 27.sp); Text(reading, color = GreenDark, fontSize = 11.sp, fontWeight = FontWeight.Bold) } }; repeat(5-row.size) { Spacer(Modifier.weight(1f)) } }; Spacer(Modifier.height(8.dp)) }
            Spacer(Modifier.height(8.dp)); Text("Подсказка: хирагана чаще используется для японских слов и грамматики, катакана — для иностранных слов, например コーヒー (кофе).", color = Muted, fontSize = 12.sp, lineHeight = 18.sp, modifier = Modifier.clip(RoundedCornerShape(16.dp)).background(Paper).padding(14.dp))
        }
        Spacer(Modifier.height(20.dp)); Text("Азбука не смешивается с тематическими уроками — здесь отдельный учебный маршрут.", color = Muted, fontSize = 11.sp)
    }
}

@Composable private fun InfoChip(text: String) { Text(text, Modifier.clip(CircleShape).background(Mint).padding(horizontal = 10.dp, vertical = 7.dp), color = GreenDark, fontSize = 11.sp, fontWeight = FontWeight.Bold) }

private val words = listOf(Triple("こんにちは", "конничива", "привет / здравствуйте"), Triple("ありがとう", "аригато", "спасибо"), Triple("すみません", "сумимасэн", "извините"), Triple("わたし", "ватаси", "я"), Triple("ともだち", "томодачи", "друг"), Triple("ほん", "хон", "книга"), Triple("みず", "мидзу", "вода"), Triple("ねこ", "нэко", "кошка"), Triple("いぬ", "ину", "собака"), Triple("おいしい", "ойсии", "вкусно"), Triple("えき", "эки", "станция"), Triple("どこ", "доко", "где"), Triple("おはようございます", "охаё годзаимас", "доброе утро"), Triple("またね", "мата нэ", "увидимся"))
@Composable private fun WordsPage(onSpeak: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(setOf("こんにちは", "ありがとう", "すみません")) }
    val filtered = words.filter { (jp, romaji, ru) -> listOf(jp, romaji, ru).any { it.contains(query, true) } }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("ТВОЙ СЛОВАРИК", color = GreenDark, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp); Text("Слова", fontSize = 28.sp, color = Ink, fontWeight = FontWeight.ExtraBold); Text("Японский • произношение • перевод", color = Muted, fontSize = 13.sp); Spacer(Modifier.height(15.dp))
        OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Найти слово или перевод…") }, leadingIcon = { Icon(Icons.Filled.Explore, null) }, singleLine = true, shape = RoundedCornerShape(16.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = GreenDark, unfocusedBorderColor = Line))
        Spacer(Modifier.height(12.dp)); Text("${filtered.size} слов", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 20.dp)) { items(filtered) { (jp, romaji, ru) -> Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Paper).padding(13.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(jp, color = Ink, fontSize = 23.sp, fontWeight = FontWeight.Medium); Text(romaji, color = GreenDark, fontSize = 12.sp, fontWeight = FontWeight.Bold); Text(ru, color = Muted, fontSize = 13.sp) }; IconButton(onClick = { onSpeak(jp) }) { Icon(Icons.Filled.VolumeUp, "Послушать", tint = GreenDark) }; Text(if (jp in saved) "★" else "☆", modifier = Modifier.clickable { saved = if (jp in saved) saved - jp else saved + jp }.padding(5.dp), fontSize = 22.sp, color = Orange) } } }
    }
}

@Composable private fun ReviewPage(onSpeak: (String) -> Unit, onBack: () -> Unit) {
    var index by remember { mutableIntStateOf(0) }; var reveal by remember { mutableStateOf(false) }
    val item = words[index % words.size]
    Column(Modifier.fillMaxSize().padding(20.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Filled.Close, null) }; Text("Повторение", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Ink) }; Text("Вспоминай японские слова по карточкам.", color = Muted); Spacer(Modifier.height(22.dp)); Column(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(28.dp)).background(Paper).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) { Text("КАРТОЧКА ${index+1}", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(25.dp)); Text(item.first, fontSize = 48.sp, color = Ink, fontWeight = FontWeight.Medium); Spacer(Modifier.height(10.dp)); if (reveal) { Text(item.second, fontSize = 18.sp, color = GreenDark, fontWeight = FontWeight.Bold); Text(item.third, fontSize = 18.sp, color = Ink) } else Text("Как это читается и что означает?", color = Muted, textAlign = TextAlign.Center); Spacer(Modifier.height(22.dp)); OutlinedButton(onClick = { onSpeak(item.first) }) { Icon(Icons.Filled.VolumeUp, null); Spacer(Modifier.width(6.dp)); Text("Послушать") }; Spacer(Modifier.height(14.dp)); Button(onClick = { if (!reveal) reveal = true else { index++; reveal = false } }, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(15.dp)) { Text(if (reveal) "Следующее слово →" else "Показать ответ") } } }
}

@Composable private fun GrammarPage(onBack: () -> Unit) {
    val rules = listOf("は (ва) — тема предложения" to "わたしはアナです。\nВатаси ва Ана дэсу.\nЯ — Анна.\n\nは пишется как «ха», но в роли частицы темы читается «ва»." , "です (дэсу) — вежливая связка" to "これはほんです。\nКорэ ва хон дэсу.\nЭто книга.\n\nВ конце фразы です делает высказывание вежливым." , "か (ка) — вопрос" to "これはなんですか。\nКорэ ва нан дэсу ка.\nЧто это?\n\nПоставь か в конец фразы, чтобы сделать вопрос." , "の (но) — принадлежность" to "わたしのほん\nВатаси но хон.\nМоя книга.\n\nСхема: владелец + の + предмет." , "を (о) — объект действия" to "みずをのみます。\nМидзу о номимас.\nЯ пью воду.\n\nを указывает на то, на что направлено действие; обычно читается «о»." )
    Column(Modifier.fillMaxSize().padding(18.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Filled.Close, null) }; Text("Грамматика", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = Ink) }; Text("Короткие объяснения с примерами и переводом.", color = Muted, fontSize = 13.sp); Spacer(Modifier.height(12.dp)); LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) { items(rules) { (title, body) -> Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Paper).padding(17.dp)) { Text(title, fontSize = 18.sp, color = GreenDark, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.height(8.dp)); Text(body, color = Ink, fontSize = 14.sp, lineHeight = 22.sp) } } } }
}

@Composable private fun ProfilePage(xp: Int, done: Int, streak: Int) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(15.dp)); Box(Modifier.size(112.dp).clip(CircleShape).background(Mint), contentAlignment = Alignment.Center) { Text("🐕", fontSize = 64.sp) }; Spacer(Modifier.height(12.dp)); Text("Твой профиль", fontSize = 27.sp, color = Ink, fontWeight = FontWeight.ExtraBold); Text("Учись в своём ритме вместе с Юки", color = Muted, fontSize = 13.sp); Spacer(Modifier.height(22.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { ProfileStat("⚡", xp.toString(), "опыта"); ProfileStat("📚", done.toString(), "уроков"); ProfileStat("🔥", streak.toString(), "дней подряд") }
        Spacer(Modifier.height(22.dp)); Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Paper).padding(18.dp)) { Text("Твои достижения", color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp); Spacer(Modifier.height(13.dp)); Achievement("🌱", "Первый росток", "Заверши первый урок", done >= 1); Achievement("📖", "Уже читатель", "Пройди 5 уроков", done >= 5); Achievement("🏆", "Первые главы", "Пройди 10 уроков", done >= 10) }
        Spacer(Modifier.height(20.dp)); Text("SHIBA YUKI", color = GreenDark, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp); Text("Разработчик: Twiksi", color = Muted, fontSize = 12.sp); Text("Версия 2.0 • Учим японский с нуля", color = Muted, fontSize = 11.sp)
    }
}
@Composable private fun ProfileStat(icon: String, number: String, caption: String) { Column(Modifier.width(95.dp).clip(RoundedCornerShape(18.dp)).background(Paper).padding(vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(icon, fontSize = 23.sp); Text(number, color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp); Text(caption, color = Muted, fontSize = 10.sp, textAlign = TextAlign.Center) } }
@Composable private fun Achievement(icon: String, title: String, subtitle: String, unlocked: Boolean) { Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(43.dp).clip(RoundedCornerShape(14.dp)).background(if (unlocked) Peach else Cream), contentAlignment = Alignment.Center) { Text(if (unlocked) icon else "🔒", fontSize = 21.sp) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(title, color = if (unlocked) Ink else Muted, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, fontSize = 11.sp) }; if (unlocked) Icon(Icons.Filled.Check, null, tint = Green) } }
