package com.nexo.kotoba

import android.os.Bundle
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Handler
import android.os.Looper
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.zIndex
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

private object AppContextHolder { var context: android.content.Context? = null }

enum class Screen { HOME, LEARN, KANA, REVIEW, GRAMMAR, DICTIONARY, PROFILE }

private val Ink = Color(0xFF253044)
private val Muted = Color(0xFF7B8798)
private val Cream = Color(0xFFFFFBF5)
private val Paper = Color(0xFFFFFFFF)
private val Green = Color(0xFF58B878)
private val GreenDark = Color(0xFF318A57)
private val Mint = Color(0xFFE8F7EC)
private val Orange = Color(0xFFFFA64D)
private val Peach = Color(0xFFFFE8D6)
private val Purple = Color(0xFF8876E8)
private val Lavender = Color(0xFFF0EDFF)
private val Blue = Color(0xFF63B6E8)
private val Line = Color(0xFFE8E7E1)

private enum class YukiTab(val title: String) { PATH("Путь"), KANA("Азбука"), WORDS("Слова"), PROFILE("Профиль") }
private enum class YukiPage { MAIN, UNIT, LESSON, STORY, DIALOGUES, CONVERSATION, KANA, WORDS, PROFILE, REVIEW, GRAMMAR }
private data class Lesson(val id: Int, val title: String, val subtitle: String, val chapter: Int, val xp: Int = 10, val items: List<QuizItem>, val teachingWords: List<VocabEntry> = emptyList())
private data class QuizItem(val prompt: String, val hint: String, val choices: List<String>, val answer: String, val explain: String, val reading: String = "")
private data class Chapter(val id: Int, val title: String, val subtitle: String, val color: Color, val icon: String)

private val chapters = listOf(
    Chapter(1, "Знакомство и вежливость", "Приветствия и первые диалоги", Green, "🌱"),
    Chapter(2, "О себе и знакомство", "Имя, возраст и личные сведения", Orange, "🪪"),
    Chapter(3, "Семья и люди", "Родственники и описание людей", Purple, "👨‍👩‍👧"),
    Chapter(4, "Числа, даты и календарь", "Счёт, дни недели, месяцы и даты", Blue, "🔢"),
    Chapter(5, "Время и расписание", "Часы, минуты и планы", Color(0xFFDA7C5A), "⏰"),
    Chapter(6, "Повседневная жизнь", "Распорядок и привычки", Color(0xFF4FA6A0), "☀️"),
    Chapter(7, "Дом и быт", "Комнаты, мебель и жильё", Color(0xFF8A79D8), "🏠"),
    Chapter(8, "Еда и продукты", "Продукты и супермаркет", Color(0xFFE58D62), "🥕"),
    Chapter(9, "Ресторан и кафе", "Заказ, счёт и этикет", Color(0xFF5899D5), "🍜"),
    Chapter(10, "Покупки и деньги", "Цены, одежда и оплата", Color(0xFF6BAE78), "🛍️"),
    Chapter(11, "Город и направления", "Как спросить дорогу", Green, "🗺️"),
    Chapter(12, "Транспорт и станция", "Поезда, билеты и пересадки", Orange, "🚉"),
    Chapter(13, "Путешествие и отель", "Бронирование и багаж", Purple, "🧳"),
    Chapter(14, "Школа и университет", "Занятия, вопросы и экзамены", Blue, "🎓"),
    Chapter(15, "Работа и профессии", "Рабочие задачи и общение", Color(0xFFDA7C5A), "💼"),
    Chapter(16, "Здоровье, больница и аптека", "Симптомы, врач и лекарства", Color(0xFF4FA6A0), "🏥"),
    Chapter(17, "Погода и времена года", "Прогноз и сезонные планы", Color(0xFF8A79D8), "🌦️"),
    Chapter(18, "Хобби, спорт и досуг", "Интересы, спорт и мероприятия", Color(0xFFE58D62), "🎮"),
    Chapter(19, "Друзья и общение", "Приглашения и встречи", Color(0xFF5899D5), "💬"),
    Chapter(20, "Телефон и интернет", "Звонки, сообщения и приложения", Color(0xFF6BAE78), "📱"),
    Chapter(21, "Грамматика предложений", "Частицы, вопросы и отрицание", Green, "📘"),
    Chapter(22, "Прошлое и планы", "Рассказываем о событиях", Orange, "🗓️"),
    Chapter(23, "Описания и сравнения", "Качества, мнения и выбор", Purple, "🎨"),
    Chapter(24, "Услуги и повседневные дела", "Почта, банк и другие службы", Blue, "🏪"),
    Chapter(25, "Безопасность и экстренные случаи", "Как действовать в сложной ситуации", Color(0xFFDA7C5A), "🆘"),
    Chapter(26, "Повторение A2 и мост к B1", "Большие диалоги и самостоятельность", Color(0xFF4FA6A0), "🏆")
)
private data class VocabEntry(val jp: String, val romaji: String, val ru: String)
private data class LessonSpec(val title: String, val subtitle: String, val words: List<VocabEntry>)
private data class ChapterSpec(val id: Int, val title: String, val subtitle: String, val lessons: List<LessonSpec>)

private val curriculum: List<ChapterSpec> by lazy {
    val json = org.json.JSONArray(
        com.nexo.kotoba.AppContextHolder.context!!.assets.open("curriculum.json").bufferedReader().use { it.readText() }
    )
    (0 until json.length()).map { ci ->
        val chapter = json.getJSONObject(ci)
        val lessonJson = chapter.getJSONArray("lessons")
        ChapterSpec(chapter.getInt("id"), chapter.getString("title"), chapter.getString("subtitle"),
            (0 until lessonJson.length()).map { li ->
                val lesson = lessonJson.getJSONObject(li)
                val wordsJson = lesson.getJSONArray("words")
                LessonSpec(lesson.getString("title"), lesson.getString("subtitle"), (0 until wordsJson.length()).map { wi ->
                    val word = wordsJson.getJSONObject(wi)
                    VocabEntry(word.getString("jp"), word.getString("romaji"), word.getString("ru"))
                })
            })
    }
}
private val allVocabulary: List<VocabEntry> by lazy { curriculum.flatMap { it.lessons }.flatMap { it.words }.distinctBy { it.jp } }
private val lessons: List<Lesson> by lazy {
    curriculum.flatMap { chapter -> chapter.lessons.mapIndexed { lessonIndex, spec ->
        val id = curriculum.takeWhile { it.id < chapter.id }.sumOf { it.lessons.size } + lessonIndex + 1
        val questions = spec.words.flatMap { word ->
            val pool = allVocabulary.filter { it.jp != word.jp }
            val ruDistractors = pool.filter { it.ru != word.ru }.shuffled(kotlin.random.Random(id * 101 + word.jp.hashCode())).map { it.ru }.distinct().take(3)
            val jpDistractors = pool.shuffled(kotlin.random.Random(id * 211 + word.jp.hashCode())).map { it.jp }.distinct().take(3)
            val readingDistractors = pool.filter { it.romaji != word.romaji }.shuffled(kotlin.random.Random(id * 307 + word.jp.hashCode())).map { it.romaji }.distinct().take(3)
            listOf(
                QuizItem(word.jp, "Выбери русский перевод.", (listOf(word.ru) + ruDistractors).distinct().shuffled(kotlin.random.Random(id * 31 + word.jp.hashCode())), word.ru, "${word.romaji} — «${word.ru}». Это слово стоит произнести вслух и повторить позже.", word.romaji),
                QuizItem("«${word.ru}»", "Выбери японскую запись.", (listOf(word.jp) + jpDistractors).distinct().shuffled(kotlin.random.Random(id * 41 + word.jp.hashCode())), word.jp, "${word.jp} читается ${word.romaji} и означает «${word.ru}».", ""),
                QuizItem("Как читается: ${word.jp}?", "Выбери чтение латиницей (ромадзи).", (listOf(word.romaji) + readingDistractors).distinct().shuffled(kotlin.random.Random(id * 53 + word.jp.hashCode())), word.romaji, "Чтение: ${word.romaji}. Значение: «${word.ru}».", "")
            )
        }.toMutableList()
        // The other nine tasks cover each word in three ways. Add a mixed reading-and-meaning
        // recap so every lesson really contains ten questions, not nine.
        val recapWord = spec.words.first()
        val recapPool = allVocabulary.filter { it.jp != recapWord.jp && it.romaji != recapWord.romaji }
        val recapChoices = (listOf("${recapWord.jp} — ${recapWord.romaji}") + recapPool
            .shuffled(kotlin.random.Random(id * 887 + recapWord.jp.hashCode()))
            .map { "${it.jp} — ${it.romaji}" }.distinct().take(3))
            .distinct().shuffled(kotlin.random.Random(id * 991 + recapWord.jp.hashCode()))
        questions.add(QuizItem(
            "Как записать и прочитать слово «${recapWord.ru}»?",
            "Нужно выбрать и японские знаки, и их чтение.", recapChoices,
            "${recapWord.jp} — ${recapWord.romaji}",
            "${recapWord.jp} читается ${recapWord.romaji} и означает «${recapWord.ru}»."
        ))
        Lesson(id, spec.title, spec.subtitle, chapter.id, 15, questions, spec.words)
    } }
}


private data class StoryBeat(val jp: String, val romaji: String, val translation: String, val question: String, val choices: List<String>, val answer: String, val explanation: String)
private data class YukiStory(val chapterId: Int, val title: String, val description: String, val beats: List<StoryBeat>)
private data class DialogueChoice(val jp: String, val romaji: String, val ru: String)
private data class DialogueTurn(val promptJp: String, val promptRomaji: String, val promptRu: String, val question: String, val choices: List<DialogueChoice>, val answer: String, val replyJp: String, val replyRomaji: String, val replyRu: String)
private data class YukiDialogue(val id: String, val chapterId: Int, val title: String, val subtitle: String, val turns: List<DialogueTurn>)
private data class ReviewMistake(val key: String, val lessonTitle: String, val chapter: Int, val prompt: String, val hint: String, val choices: List<String>, val answer: String, val explain: String, val reading: String, val wrongAnswer: String)
private fun loadMistakes(raw: String?): List<ReviewMistake> = runCatching {
    val array = org.json.JSONArray(raw ?: "[]")
    (0 until array.length()).map { i ->
        val o = array.getJSONObject(i); val ca = o.getJSONArray("choices")
        ReviewMistake(o.getString("key"), o.getString("lessonTitle"), o.getInt("chapter"), o.getString("prompt"), o.getString("hint"),
            (0 until ca.length()).map { ca.getString(it) }, o.getString("answer"), o.getString("explain"), o.optString("reading", ""), o.optString("wrongAnswer", ""))
    }
}.getOrDefault(emptyList())
private fun encodeMistakes(items: List<ReviewMistake>): String {
    val array = org.json.JSONArray()
    items.forEach { m -> array.put(org.json.JSONObject().put("key",m.key).put("lessonTitle",m.lessonTitle).put("chapter",m.chapter).put("prompt",m.prompt).put("hint",m.hint).put("choices",org.json.JSONArray(m.choices)).put("answer",m.answer).put("explain",m.explain).put("reading",m.reading).put("wrongAnswer",m.wrongAnswer)) }
    return array.toString()
}
private val storyLibrary: List<YukiStory> by lazy {
    val json = org.json.JSONArray(com.nexo.kotoba.AppContextHolder.context!!.assets.open("stories.json").bufferedReader().use { it.readText() })
    (0 until json.length()).map { i ->
        val item = json.getJSONObject(i); val beatsJson = item.getJSONArray("beats")
        YukiStory(item.getInt("chapterId"), item.getString("title"), item.getString("description"), (0 until beatsJson.length()).map { j ->
            val b = beatsJson.getJSONObject(j); val opts = b.getJSONArray("choices")
            StoryBeat(b.getString("jp"), b.getString("romaji"), b.getString("translation"), b.getString("question"), (0 until opts.length()).map { opts.getString(it) }, b.getString("answer"), b.getString("explanation"))
        })
    }
}
private val dialogueLibrary: List<YukiDialogue> by lazy {
    val json = org.json.JSONArray(com.nexo.kotoba.AppContextHolder.context!!.assets.open("dialogues.json").bufferedReader().use { it.readText() })
    (0 until json.length()).map { i ->
        val d=json.getJSONObject(i); val turnsJson=d.getJSONArray("turns")
        YukiDialogue(d.getString("id"),d.getInt("chapterId"),d.getString("title"),d.getString("subtitle"),(0 until turnsJson.length()).map { j ->
            val t=turnsJson.getJSONObject(j); val choicesJson=t.getJSONArray("choices")
            DialogueTurn(t.getString("promptJp"),t.getString("promptRomaji"),t.getString("promptRu"),t.getString("question"),(0 until choicesJson.length()).map { k -> val c=choicesJson.getJSONObject(k); DialogueChoice(c.getString("jp"),c.getString("romaji"),c.getString("ru")) },t.getString("answer"),t.getString("replyJp"),t.getString("replyRomaji"),t.getString("replyRu"))
        })
    }
}
private data class GrammarRule(val title: String, val subtitle: String, val example: String, val explanation: String)
private val grammarLibrary: List<GrammarRule> by lazy {
    val json = org.json.JSONArray(com.nexo.kotoba.AppContextHolder.context!!.assets.open("grammar.json").bufferedReader().use { it.readText() })
    (0 until json.length()).map { i -> val r=json.getJSONObject(i); GrammarRule(r.getString("title"),r.getString("subtitle"),r.getString("example"),r.getString("explanation")) }
}

private val romanization = mapOf(
    "こんにちは" to "konnichiwa", "ありがとう" to "arigatou", "すみません" to "sumimasen", "さようなら" to "sayounara", "おはよう" to "ohayou", "こんばんは" to "konbanwa", "アナじゃない。" to "Ana janai", "おはようございます" to "ohayou gozaimasu", "おはようございます" to "ohayou gozaimasu", "こんばんは" to "konbanwa", "さようなら" to "sayounara", "はい" to "hai", "いいえ" to "iie", "わたし" to "watashi", "わたしはアナです。" to "watashi wa Ana desu", "アナですか。" to "Ana desu ka", "いいえ、ちがいます。" to "iie, chigaimasu", "ともだち" to "tomodachi", "はは" to "haha", "ちち" to "chichi", "せんせい" to "sensei", "ほん" to "hon", "これはなんですか。" to "kore wa nan desu ka", "みず" to "mizu", "すきです" to "suki desu", "ねこ" to "neko", "いぬ" to "inu", "いまなんじですか。" to "ima nanji desu ka", "いち" to "ichi", "ごじ" to "goji", "えき" to "eki", "どこ" to "doko", "トイレはどこですか。" to "toire wa doko desu ka", "みずをください。" to "mizu o kudasai", "おいしい" to "oishii", "コーヒー" to "koohii", "ほんをよみます。" to "hon o yomimasu", "またね" to "mata ne", "たべます" to "tabemasu", "のみます" to "nomimasu", "ねます" to "nemasu", "よみます" to "yomimasu", "みます" to "mimasu", "ききます" to "kikimasu", "がっこう" to "gakkou", "にほんご" to "nihongo", "べんきょう" to "benkyou", "みせ" to "mise", "こうえん" to "kouen", "びょういん" to "byouin", "でんしゃ" to "densha", "くるま" to "kuruma", "じてんしゃ" to "jitensha", "いくら" to "ikura", "おかね" to "okane", "たかい" to "takai", "あめ" to "ame", "ゆき" to "yuki", "あつい" to "atsui", "うれしい" to "ureshii", "かなしい" to "kanashii", "つかれた" to "tsukareta", "おんがく" to "ongaku", "えいが" to "eiga", "ゲーム" to "geemu", "おねがいします" to "onegaishimasu", "どうぞ" to "douzo", "だいじょうぶ" to "daijoubu", "だれ" to "dare", "いつ" to "itsu", "なぜ" to "naze", "つくえ" to "tsukue", "いす" to "isu", "まど" to "mado", "メニュー" to "menyuu", "ごはん" to "gohan", "おちゃ" to "ocha", "おおきい" to "ookii", "ちいさい" to "chiisai", "あまい" to "amai", "みぎ" to "migi", "ひだり" to "hidari", "まっすぐ" to "massugu", "ホテル" to "hoteru", "へや" to "heya", "かぎ" to "kagi", "きょう" to "kyou", "あした" to "ashita", "あさ" to "asa", "いっしょ" to "issho", "はなします" to "hanashimasu", "あいます" to "aimasu", "いきます" to "ikimasu", "きます" to "kimasu", "かえります" to "kaerimasu", "はじめまして" to "hajimemashite", "よろしく" to "yoroshiku", "またあした" to "mata ashita"
)
private val kanaRoman = mapOf(
    'あ' to "a",'い' to "i",'う' to "u",'え' to "e",'お' to "o",'か' to "ka",'き' to "ki",'く' to "ku",'け' to "ke",'こ' to "ko",'さ' to "sa",'し' to "shi",'す' to "su",'せ' to "se",'そ' to "so",'た' to "ta",'ち' to "chi",'つ' to "tsu",'て' to "te",'と' to "to",'な' to "na",'に' to "ni",'ぬ' to "nu",'ね' to "ne",'の' to "no",'は' to "ha",'ひ' to "hi",'ふ' to "fu",'へ' to "he",'ほ' to "ho",'ま' to "ma",'み' to "mi",'む' to "mu",'め' to "me",'も' to "mo",'や' to "ya",'ゆ' to "yu",'よ' to "yo",'ら' to "ra",'り' to "ri",'る' to "ru",'れ' to "re",'ろ' to "ro",'わ' to "wa",'を' to "o",'ん' to "n",
    'が' to "ga",'ぎ' to "gi",'ぐ' to "gu",'げ' to "ge",'ご' to "go",'ざ' to "za",'じ' to "ji",'ず' to "zu",'ぜ' to "ze",'ぞ' to "zo",'だ' to "da",'ぢ' to "ji",'づ' to "zu",'で' to "de",'ど' to "do",'ば' to "ba",'び' to "bi",'ぶ' to "bu",'べ' to "be",'ぼ' to "bo",'ぱ' to "pa",'ぴ' to "pi",'ぷ' to "pu",'ぺ' to "pe",'ぽ' to "po",'ぁ' to "a",'ぃ' to "i",'ぅ' to "u",'ぇ' to "e",'ぉ' to "o",'っ' to "",'ゃ' to "ya",'ゅ' to "yu",'ょ' to "yo",'ー' to "-",
    'ア' to "a",'イ' to "i",'ウ' to "u",'エ' to "e",'オ' to "o",'カ' to "ka",'キ' to "ki",'ク' to "ku",'ケ' to "ke",'コ' to "ko",'サ' to "sa",'シ' to "shi",'ス' to "su",'セ' to "se",'ソ' to "so",'タ' to "ta",'チ' to "chi",'ツ' to "tsu",'テ' to "te",'ト' to "to",'ナ' to "na",'ニ' to "ni",'ヌ' to "nu",'ネ' to "ne",'ノ' to "no",'ハ' to "ha",'ヒ' to "hi",'フ' to "fu",'ヘ' to "he",'ホ' to "ho",'マ' to "ma",'ミ' to "mi",'ム' to "mu",'メ' to "me",'モ' to "mo",'ヤ' to "ya",'ユ' to "yu",'ヨ' to "yo",'ラ' to "ra",'リ' to "ri",'ル' to "ru",'レ' to "re",'ロ' to "ro",'ワ' to "wa",'ヲ' to "o",'ン' to "n",'ガ' to "ga",'ギ' to "gi",'グ' to "gu",'ゲ' to "ge",'ゴ' to "go",'ザ' to "za",'ジ' to "ji",'ズ' to "zu",'ゼ' to "ze",'ゾ' to "zo",'ダ' to "da",'デ' to "de",'ド' to "do",'バ' to "ba",'ビ' to "bi",'ブ' to "bu",'ベ' to "be",'ボ' to "bo",'パ' to "pa",'ピ' to "pi",'プ' to "pu",'ペ' to "pe",'ポ' to "po"
)
private fun romanize(text: String): String {
    romanization[text]?.let { return it }
    allVocabulary.firstOrNull { it.jp == text }?.romaji?.let { return it }
    if (!text.any { it in 'ぁ'..'ん' || it in 'ァ'..'ヶ' }) return ""
    val chars = text.toCharArray()
    val out = StringBuilder()
    var i = 0
    while (i < chars.size) {
        val c = chars[i]
        if (c == 'っ' || c == 'ッ') {
            val next = chars.getOrNull(i + 1)
            val nextRomaji = next?.let { kanaRoman[it] }.orEmpty()
            if (nextRomaji.isNotEmpty()) out.append(nextRomaji.first())
            i++; continue
        }
        val small = chars.getOrNull(i + 1)
        val pair = when (c) {
            'き' -> mapOf('ゃ' to "kya", 'ゅ' to "kyu", 'ょ' to "kyo")
            'し' -> mapOf('ゃ' to "sha", 'ゅ' to "shu", 'ょ' to "sho")
            'ち' -> mapOf('ゃ' to "cha", 'ゅ' to "chu", 'ょ' to "cho")
            'に' -> mapOf('ゃ' to "nya", 'ゅ' to "nyu", 'ょ' to "nyo")
            'ひ' -> mapOf('ゃ' to "hya", 'ゅ' to "hyu", 'ょ' to "hyo")
            'み' -> mapOf('ゃ' to "mya", 'ゅ' to "myu", 'ょ' to "myo")
            'り' -> mapOf('ゃ' to "rya", 'ゅ' to "ryu", 'ょ' to "ryo")
            'キ' -> mapOf('ャ' to "kya", 'ュ' to "kyu", 'ョ' to "kyo")
            'シ' -> mapOf('ャ' to "sha", 'ュ' to "shu", 'ョ' to "sho")
            'チ' -> mapOf('ャ' to "cha", 'ュ' to "chu", 'ョ' to "cho")
            else -> emptyMap()
        }
        val combo = if (small != null) pair[small] else null
        if (combo != null) { out.append(combo); i += 2 } else { out.append(kanaRoman[c] ?: c); i++ }
    }
    return out.toString().replace("、", ", ").replace("。", "").trim()
}

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var japaneseVoiceAvailable = false
    private var pendingSpeech: String? = null
    private var installPromptShown = false
    private var soundPool: SoundPool? = null
    private val soundIds = mutableMapOf<String, Int>()
    private val loadedSounds = mutableSetOf<Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppContextHolder.context = applicationContext
        window.statusBarColor = android.graphics.Color.rgb(255,251,245)
        window.navigationBarColor = android.graphics.Color.rgb(255,251,245)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        // Post initialization onto the main queue. Some Android engines invoke their callback
        // before the assignment to `tts` has completed; reading the field directly in that
        // callback used to leave the app permanently marked as having no Japanese voice.
        soundPool = SoundPool.Builder().setMaxStreams(3).setAudioAttributes(
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        ).build().also { pool ->
            pool.setOnLoadCompleteListener { _, sampleId, status -> if (status == 0) loadedSounds.add(sampleId) }
            soundIds["correct"] = pool.load(this, R.raw.sfx_correct, 1)
            soundIds["wrong"] = pool.load(this, R.raw.sfx_wrong, 1)
            soundIds["finish"] = pool.load(this, R.raw.sfx_finish, 1)
            soundIds["start"] = pool.load(this, R.raw.sfx_start, 1)
        }
        tts = TextToSpeech(applicationContext) { status ->
            Handler(Looper.getMainLooper()).post {
                val engine = tts
                if (status == TextToSpeech.SUCCESS && engine != null) {
                    runCatching {
                        engine.setAudioAttributes(AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                        val languageStatus = engine.isLanguageAvailable(Locale.JAPAN)
                        japaneseVoiceAvailable = languageStatus >= TextToSpeech.LANG_AVAILABLE
                        if (japaneseVoiceAvailable) {
                            val languageResult = engine.setLanguage(Locale.JAPAN)
                            japaneseVoiceAvailable = languageResult >= TextToSpeech.LANG_AVAILABLE
                            val voice = engine.voices.orEmpty()
                                .filter { it.locale.language == "ja" }
                                .maxWithOrNull(compareBy<Voice> { it.quality }.thenBy { if (it.isNetworkConnectionRequired) 1 else 0 })
                            if (voice != null) engine.voice = voice
                            engine.setSpeechRate(0.88f)
                            engine.setPitch(1.08f)
                            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                                override fun onStart(utteranceId: String?) {}
                                override fun onDone(utteranceId: String?) {}
                                override fun onError(utteranceId: String?) {
                                    runOnUiThread { Toast.makeText(this@MainActivity, "Японский голос не смог произнести фразу. Проверь громкость мультимедиа и выбранный движок озвучки.", Toast.LENGTH_LONG).show() }
                                }
                                override fun onError(utteranceId: String?, errorCode: Int) = onError(utteranceId)
                            })
                        }
                    }.onFailure { japaneseVoiceAvailable = false }
                }
                ttsReady = true
                pendingSpeech?.also { pendingSpeech = null; speak(it) }
            }
        }
        setContent { ShibaYukiApp(onSpeak = { speak(it) }, onFeedback = { playFeedback(it) }) }
    }

    private fun playFeedback(kind: String) {
        val id = soundIds[kind] ?: return
        if (id in loadedSounds) soundPool?.play(id, 0.8f, 0.8f, 1, 0, 1f)
    }

    private fun speak(text: String) {
        if (text.isBlank()) return
        if (!ttsReady) { pendingSpeech = text; return }
        val engine = tts
        if (engine == null || !japaneseVoiceAvailable) {
            Toast.makeText(this, "Японский голос не запустился. Открой настройки Android → Преобразование текста в речь и выбери движок Google с японским голосом.", Toast.LENGTH_LONG).show()
            if (!installPromptShown) {
                installPromptShown = true
                runCatching { startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)) }
            }
            return
        }
        val result = runCatching { engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "yuki-${System.currentTimeMillis()}") }.getOrDefault(TextToSpeech.ERROR)
        if (result == TextToSpeech.ERROR) Toast.makeText(this, "Озвучка не стартовала. Проверь громкость мультимедиа и голосовой движок Android.", Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        tts?.stop(); tts?.shutdown(); soundPool?.release(); soundPool = null; super.onDestroy()
    }
}

@Composable
private fun ShibaYukiApp(onSpeak: (String) -> Unit, onFeedback: (String) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("shiba_yuki_progress", android.content.Context.MODE_PRIVATE) }
    var xp by remember { mutableIntStateOf(prefs.getInt("xp", 0)) }
    var completed by remember { mutableStateOf(prefs.getStringSet("completed", emptySet())?.toSet() ?: emptySet()) }
    var streak by remember { mutableIntStateOf(prefs.getInt("streak", 0)) }
    var lastStudyDate by remember { mutableStateOf(prefs.getString("last_study_date", "") ?: "") }
    var tab by remember { mutableStateOf(YukiTab.PATH) }
    var page by remember { mutableStateOf(YukiPage.MAIN) }
    var selectedLesson by remember { mutableStateOf<Lesson?>(null) }
    var selectedDialogue by remember { mutableStateOf<YukiDialogue?>(null) }
    var selectedChapter by remember { mutableIntStateOf(lessons.firstOrNull { it.id.toString() !in completed }?.chapter ?: 1) }
    var storyBeatIndex by remember { mutableIntStateOf(0) }
    var dialogueTurnIndex by remember { mutableIntStateOf(0) }
    var lessonIndex by remember { mutableIntStateOf(0) }
    var mistakes by remember { mutableStateOf(loadMistakes(prefs.getString("mistakes", "[]"))) }
    var selectedKana by remember { mutableStateOf("ひらがな") }
    val haptics = LocalHapticFeedback.current

    fun saveProgress(newXp: Int, newCompleted: Set<String>) {
        xp = newXp; completed = newCompleted
        prefs.edit().putInt("xp", newXp).putStringSet("completed", newCompleted).putInt("streak", streak).putString("last_study_date", lastStudyDate).apply()
    }
    fun openTab(newTab: YukiTab) { tab = newTab; page = when(newTab) { YukiTab.PATH -> YukiPage.MAIN; YukiTab.KANA -> YukiPage.KANA; YukiTab.WORDS -> YukiPage.WORDS; YukiTab.PROFILE -> YukiPage.PROFILE } }
    fun saveMistakes(updated: List<ReviewMistake>) { mistakes = updated; prefs.edit().putString("mistakes", encodeMistakes(updated)).apply() }
    fun recordMistake(lesson: Lesson, question: QuizItem, selectedAnswer: String) {
        val key = "${lesson.id}:${question.prompt}"
        if (mistakes.none { it.key == key }) saveMistakes(mistakes + ReviewMistake(key, lesson.title, lesson.chapter, question.prompt, question.hint, question.choices, question.answer, question.explain, question.reading, selectedAnswer))
    }
    BackHandler(enabled = page != YukiPage.MAIN) {
        page = when(page) { YukiPage.LESSON, YukiPage.STORY, YukiPage.DIALOGUES -> YukiPage.MAIN; YukiPage.CONVERSATION -> YukiPage.DIALOGUES; else -> YukiPage.MAIN }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = GreenDark, onPrimary = Color.White, background = Cream, surface = Paper, onSurface = Ink, secondary = Orange)) {
        Scaffold(containerColor = Cream, bottomBar = {
            if (page != YukiPage.LESSON && page != YukiPage.STORY && page != YukiPage.CONVERSATION && page != YukiPage.DIALOGUES) NavigationBar(containerColor = Paper, tonalElevation = 0.dp, windowInsets = NavigationBarDefaults.windowInsets) {
                listOf(YukiTab.PATH, YukiTab.KANA, YukiTab.WORDS, YukiTab.PROFILE).forEach { item ->
                    NavigationBarItem(selected = tab == item, onClick = { openTab(item) }, icon = {
                        val ico = when(item) { YukiTab.PATH -> Icons.Filled.Explore; YukiTab.KANA -> Icons.Filled.AutoStories; YukiTab.WORDS -> Icons.Filled.MenuBook; YukiTab.PROFILE -> Icons.Filled.School }
                        Icon(ico, null, modifier = Modifier.size(23.dp))
                    }, label = { Text(item.title, fontSize = 11.sp, fontWeight = if (tab == item) FontWeight.Bold else FontWeight.Medium) }, alwaysShowLabel = true, colors = NavigationBarItemDefaults.colors(selectedIconColor = GreenDark, selectedTextColor = GreenDark, indicatorColor = Mint, unselectedIconColor = Muted, unselectedTextColor = Muted))
                }
            }
        }) { inner ->
            AnimatedContent(targetState = page, modifier = Modifier.padding(inner), transitionSpec = { (fadeIn() + slideInHorizontally { it / 18 }) togetherWith (fadeOut() + slideOutHorizontally { -it / 18 }) }, label = "page") { current ->
                when(current) {
                    YukiPage.MAIN -> PathPage(xp, completed, streak, mistakes.size, selectedChapter,
                        onChapter = { selectedChapter = it },
                        onLesson = { lesson -> selectedChapter = lesson.chapter; selectedLesson = lesson; lessonIndex = 0; page = YukiPage.LESSON },
                        onKana = { openTab(YukiTab.KANA) }, onReview = { page = YukiPage.REVIEW }, onGrammar = { page = YukiPage.GRAMMAR })
                    YukiPage.UNIT -> UnitPage(selectedChapter, completed, onBack = { page = YukiPage.MAIN }, onStory = { storyBeatIndex = 0; page = YukiPage.STORY }, onDialogues = { page = YukiPage.DIALOGUES }, onLesson = { lesson -> selectedLesson = lesson; lessonIndex = 0; page = YukiPage.LESSON })
                    YukiPage.STORY -> storyLibrary.firstOrNull { it.chapterId == selectedChapter }?.let { story -> StoryPage(story, storyBeatIndex, onBeat = { storyBeatIndex = it }, onSpeak = onSpeak, onBack = { page = YukiPage.UNIT }) }
                    YukiPage.DIALOGUES -> DialoguesPage(selectedChapter, onBack = { page = YukiPage.UNIT }, onOpen = { dialogue -> selectedDialogue = dialogue; dialogueTurnIndex = 0; page = YukiPage.CONVERSATION })
                    YukiPage.CONVERSATION -> selectedDialogue?.let { dialogue -> ConversationPage(dialogue, dialogueTurnIndex, onTurn = { dialogueTurnIndex = it }, onSpeak = onSpeak, onBack = { page = YukiPage.DIALOGUES }) }
                    YukiPage.KANA -> KanaPage(selectedKana, { selectedKana = it }, onSpeak)
                    YukiPage.WORDS -> WordsPage(onSpeak)
                    YukiPage.PROFILE -> ProfilePage(xp, completed.size, streak, onSpeak)
                    YukiPage.REVIEW -> ReviewPage(mistakes, onResolve = { key -> saveMistakes(mistakes.filterNot { it.key == key }) }, onSpeak = onSpeak, onBack = { page = YukiPage.MAIN })
                    YukiPage.GRAMMAR -> GrammarPage(onBack = { page = YukiPage.MAIN })
                    YukiPage.LESSON -> selectedLesson?.let { lesson -> LessonPage(lesson, lessonIndex, onIndex = { lessonIndex = it }, onSpeak = onSpeak, onFeedback = onFeedback, onExit = { page = YukiPage.MAIN; selectedLesson = null }, onMistake = { q, answer -> recordMistake(lesson, q, answer) }, onFinish = { earned ->
                        val today = java.time.LocalDate.now().toString()
                        if (lastStudyDate != today) {
                            val yesterday = runCatching { java.time.LocalDate.now().minusDays(1).toString() }.getOrDefault("")
                            streak = if (lastStudyDate == yesterday) streak + 1 else 1
                            lastStudyDate = today
                        }
                        val next = completed + lesson.id.toString()
                        saveProgress(xp + earned, next)
                        prefs.edit().putString("last_study_date", lastStudyDate).putInt("streak", streak).apply()
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress); page = YukiPage.MAIN; selectedLesson = null
                    }) }
                }
            }
        }
    }
}

@Composable
private fun PathPage(
    xp: Int, completed: Set<String>, streak: Int, mistakeCount: Int, selectedChapter: Int,
    onChapter: (Int) -> Unit, onLesson: (Lesson) -> Unit, onKana: () -> Unit, onReview: () -> Unit, onGrammar: () -> Unit
) {
    val chapter = chapters.firstOrNull { it.id == selectedChapter } ?: chapters.first()
    val group = lessons.filter { it.chapter == chapter.id }
    val chapterUnlocked = chapter.id == 1 || lessons.filter { it.chapter == chapter.id - 1 }.all { it.id.toString() in completed }
    val activeIndex = group.indexOfFirst { it.id.toString() !in completed }.let { if (it < 0) group.lastIndex else it }
    val overallProgress = completed.size.toFloat() / lessons.size.coerceAtLeast(1)
    val pathScroll = rememberScrollState()
    val nodeStep = 88
    val pathHeight = (group.size * nodeStep + 24).dp
    val activeX = remember(chapter.id) { Animatable(if (activeIndex % 2 == 0) 90f else 270f) }
    val activeY = remember(chapter.id) { Animatable(maxOf(24f, ((group.size - 1 - activeIndex) * nodeStep + 15).toFloat())) }
    LaunchedEffect(chapter.id) { kotlinx.coroutines.delay(80); pathScroll.scrollTo(pathScroll.maxValue) }
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFFE9FFF1), Color(0xFFFFF9EF), Color(0xFFF2F0FF)))).padding(horizontal = 15.dp, vertical = 10.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("SHIBA YUKI · TWIKSI", fontSize = 10.sp, color = GreenDark, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.8.sp)
                Text("Твой путь в японский", fontSize = 24.sp, lineHeight = 28.sp, color = Ink, fontWeight = FontWeight.Black)
                Text("${lessons.size} уроков · растём каждый день", fontSize = 11.sp, color = Muted)
            }
            Box(Modifier.size(67.dp).shadow(9.dp, CircleShape).clip(CircleShape).background(Brush.verticalGradient(listOf(Color.White, Color(0xFFDDF6E5)))), contentAlignment = Alignment.Center) {
                Image(painterResource(R.drawable.yuki_3d), contentDescription = "Юки, трёхмерный маскот", modifier = Modifier.fillMaxSize().padding(1.dp))
            }
            Spacer(Modifier.width(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) { StatPill("🔥", streak.toString()); StatPill("⭐", "${1 + xp / 150}"); StatPill("⚡", xp.toString()) }
        }
        Spacer(Modifier.height(10.dp))
        Column(Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(22.dp)).clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(listOf(Color(0xFF24794E), Color(0xFF75C98C), Color(0xFFB6E9A7)))).padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("ТВОЙ ПРОГРЕСС", color = Color.White.copy(.83f), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.2.sp)
                    Text("${completed.size} / ${lessons.size} уроков", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Black)
                    Text("${(overallProgress * 100).toInt()}% курса завершено", color = Color.White.copy(.9f), fontSize = 11.sp)
                }
                Text("🐾", fontSize = 34.sp)
            }
            Spacer(Modifier.height(9.dp)); Box(Modifier.fillMaxWidth().height(8.dp).clip(CircleShape).background(Color.White.copy(.25f))) {
                Box(Modifier.fillMaxWidth(overallProgress.coerceIn(0f, 1f)).fillMaxHeight().clip(CircleShape).background(Brush.horizontalGradient(listOf(Color(0xFFFFE29A), Color.White))))
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("Глава ${chapter.id}: ${chapter.title}", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis); Text(chapter.subtitle, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
            Text("${group.count { it.id.toString() in completed }}/${group.size}", color = chapter.color, fontWeight = FontWeight.Black, fontSize = 14.sp)
        }
        Spacer(Modifier.height(7.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            chapters.forEach { item ->
                val unlocked = item.id == 1 || lessons.filter { it.chapter == item.id - 1 }.all { it.id.toString() in completed }
                val selected = item.id == chapter.id
                Column(Modifier.width(61.dp).shadow(if (selected) 6.dp else 1.dp, RoundedCornerShape(15.dp)).clip(RoundedCornerShape(15.dp))
                    .background(if (selected) Brush.verticalGradient(listOf(item.color, item.color.copy(alpha=.75f)) ) else Brush.verticalGradient(listOf(Color.White, Color(0xFFF1F0EA))))
                    .clickable(enabled = unlocked) { onChapter(item.id) }.padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (!unlocked) "🔒" else item.icon, fontSize = 20.sp)
                    Text("${item.id}", color = if (selected) Color.White else if (unlocked) Ink else Muted, fontSize = 11.sp, fontWeight = FontWeight.Black)
                }
            }
        }
        Spacer(Modifier.height(7.dp))
        Text("ТРОПА ЮКИ · ПОДНИМАЙСЯ ВВЕРХ", color = GreenDark, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(4.dp))
        // A reversed-looking trail: lesson 1 is at the bottom, lesson 10 is above it.
        Box(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(22.dp)).background(Brush.verticalGradient(listOf(Color(0xFFF7FFF9), Color(0xFFFFF7EC)))).verticalScroll(pathScroll)) {
            BoxWithConstraints(Modifier.fillMaxWidth().height(pathHeight)) {
                val widthDp = maxWidth.value
                val leftX = 47f
                val rightX = (widthDp - 47f).coerceAtLeast(70f)
                LaunchedEffect(chapter.id, activeIndex, widthDp) {
                    val targetX = if (activeIndex % 2 == 0) 90f else (widthDp - 90f).coerceAtLeast(70f)
                    val targetY = maxOf(24f, ((group.size - 1 - activeIndex) * nodeStep + 15).toFloat())
                    kotlinx.coroutines.coroutineScope {
                        launch { activeX.animateTo(targetX, tween(780, easing = androidx.compose.animation.core.FastOutSlowInEasing)) }
                        launch { activeY.animateTo(targetY, tween(780, easing = androidx.compose.animation.core.FastOutSlowInEasing)) }
                    }
                }
                Canvas(Modifier.fillMaxSize()) {
                    val step = nodeStep.dp.toPx()
                    val pts = group.indices.map { i -> Offset(if (i % 2 == 0) leftX.dp.toPx() else size.width - leftX.dp.toPx(), size.height - (i * step + 58.dp.toPx())) }
                    if (pts.size > 1) {
                        val path = Path().apply { moveTo(pts.first().x, pts.first().y); for (i in 1 until pts.size) { val a = pts[i-1]; val b = pts[i]; val mid = (a.y+b.y)/2f; cubicTo(a.x, mid, b.x, mid, b.x, b.y) } }
                        drawPath(path, Color(0xFF9BD9A8), style = Stroke(width = 11.dp.toPx(), cap = StrokeCap.Round))
                        drawPath(path, Color.White.copy(alpha=.9f), style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))
                    }
                }
                group.forEachIndexed { index, lesson ->
                    val done = lesson.id.toString() in completed
                    val priorDone = group.take(index).all { it.id.toString() in completed }
                    val unlocked = chapterUnlocked && (index == 0 || priorDone || done)
                    val current = lesson.id.toString() !in completed && unlocked
                    val topY = ((group.size - 1 - index) * nodeStep + 22).dp
                    Row(Modifier.offset(y = topY).align(Alignment.TopStart).fillMaxWidth().height(72.dp).padding(horizontal = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = if (index % 2 == 0) Arrangement.Start else Arrangement.End) {
                        if (index % 2 != 0) Spacer(Modifier.weight(1f))
                        if (index % 2 == 0) {
                            LessonButton3D(index + 1, done, unlocked, current, chapter.color, onClick = { if (unlocked) onLesson(lesson) })
                            Spacer(Modifier.width(8.dp))
                            LessonLabel3D(lesson, done, unlocked, current, chapter.color, Modifier.widthIn(max = 190.dp).weight(1f), onClick = { if (unlocked) onLesson(lesson) })
                        } else {
                            LessonLabel3D(lesson, done, unlocked, current, chapter.color, Modifier.widthIn(max = 190.dp).weight(1f), onClick = { if (unlocked) onLesson(lesson) })
                            Spacer(Modifier.width(8.dp))
                            LessonButton3D(index + 1, done, unlocked, current, chapter.color, onClick = { if (unlocked) onLesson(lesson) })
                        }
                        if (index % 2 == 0) Spacer(Modifier.weight(1f))
                    }
                }
                if (chapterUnlocked && activeIndex >= 0) {
                    Box(Modifier.offset(x = (activeX.value - 23f).dp, y = (activeY.value - 24f).dp).size(48.dp).zIndex(5f)
                        .shadow(10.dp, CircleShape).clip(CircleShape).background(Brush.verticalGradient(listOf(Color.White, Color(0xFFFFEBC2))))
                        .border(2.dp, Color.White, CircleShape).padding(1.dp)) {
                        Image(painterResource(R.drawable.yuki_3d), contentDescription = "Юки поднимается по тропе к следующему уроку", modifier = Modifier.fillMaxSize())
                    }
                }
            }
        }
        Spacer(Modifier.height(7.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MiniAction("🔤", "Азбука", "Отдельная тренировка", Modifier.weight(1f), onKana)
            MiniAction("🧠", "Ошибки", if (mistakeCount == 0) "Пока всё чисто" else "$mistakeCount на повтор", Modifier.weight(1f), onReview)
            MiniAction("📘", "Правила", "Грамматика", Modifier.weight(1f), onGrammar)
        }
    }
}

@Composable private fun LessonButton3D(number: Int, done: Boolean, unlocked: Boolean, current: Boolean, tint: Color, onClick: () -> Unit) {
    val pulse by animateFloatAsState(if (current) 1.06f else 1f, label = "lesson-button-pulse")
    Box(Modifier.size(66.dp).scale(pulse).shadow(if (current) 12.dp else 7.dp, CircleShape).clip(CircleShape)
        .background(Brush.verticalGradient(listOf(if (done) Color(0xFF8EE0A5) else if (current) Color(0xFFFFE59A) else if (unlocked) Color.White else Color(0xFFE2E5E0), if (done) Color(0xFF2D9C5C) else if (current) Color(0xFFFFA94F) else if (unlocked) tint.copy(alpha=.48f) else Color(0xFFBEC4BD))))
        .clickable(enabled = unlocked, onClick = onClick).padding(5.dp).shadow(2.dp, CircleShape).clip(CircleShape)
        .background(Brush.verticalGradient(listOf(Color.White.copy(alpha=.82f), if (done) Color(0xFF45B66F) else if (current) Color(0xFFFFC66C) else Color(0xFFF6FBF5))), CircleShape)
        .border(1.dp, Color.White.copy(alpha=.9f), CircleShape), contentAlignment = Alignment.Center) {
        when { done -> Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.size(29.dp)); !unlocked -> Icon(Icons.Filled.Lock, null, tint = Muted, modifier = Modifier.size(22.dp)); else -> Text(number.toString(), color = if (current) Color(0xFF8C4C13) else tint, fontSize = 23.sp, fontWeight = FontWeight.Black) }
    }
}

@Composable private fun LessonLabel3D(lesson: Lesson, done: Boolean, unlocked: Boolean, current: Boolean, tint: Color, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.shadow(if (current) 5.dp else 2.dp, RoundedCornerShape(16.dp)).clip(RoundedCornerShape(16.dp))
        .background(Brush.verticalGradient(listOf(Color.White, if (current) Color(0xFFFFF0CB) else Color(0xFFF0F8F1))))
        .border(1.dp, if (current) Color(0xFFFFD06E) else Color.White, RoundedCornerShape(16.dp))
        .clickable(enabled = unlocked, onClick = onClick).padding(horizontal = 10.dp, vertical = 8.dp)) {
        Text(lesson.title, color = if (unlocked) Ink else Muted, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 13.sp)
        Text(if (done) "Пройдено ✓" else if (current) "Юки ждёт! 🐾" else if (unlocked) "10 заданий · +XP" else "Закрыто 🔒", color = if (done) GreenDark else tint, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable private fun HeroCard(progress: Float, done: Int, onLesson: () -> Unit) {
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Brush.linearGradient(listOf(Color(0xFF287D52), Color(0xFF66BE82)))).padding(20.dp)) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("ЯПОНСКИЙ С НУЛЯ", color = Color.White.copy(.8f), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.4.sp); Spacer(Modifier.height(6.dp)); Text("Маленькие шаги —\nбольшой прогресс", color = Color.White, fontSize = 23.sp, lineHeight = 28.sp, fontWeight = FontWeight.ExtraBold) }
                Mascot(size = 88)
            }
            Spacer(Modifier.height(12.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.weight(1f).height(7.dp).clip(CircleShape).background(Color.White.copy(.25f))) { Box(Modifier.fillMaxWidth(progress.coerceIn(0f,1f)).fillMaxHeight().clip(CircleShape).background(Color.White)) }; Spacer(Modifier.width(10.dp)); Text("${(progress*100).toInt()}%", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
            Spacer(Modifier.height(7.dp)); Text("Уроков пройдено: $done из ${lessons.size}", color = Color.White.copy(.85f), fontSize = 12.sp)
            Spacer(Modifier.height(15.dp)); Button(onClick = onLesson, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = GreenDark), shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth().height(48.dp)) { Text("Продолжить обучение", fontWeight = FontWeight.ExtraBold); Spacer(Modifier.width(6.dp)); Icon(Icons.Filled.ChevronRight, null) }
        }
    }
}

@Composable private fun Mascot(size: Int) {
    val infinite = androidx.compose.animation.core.rememberInfiniteTransition(label = "yuki-bob")
    val bob by infinite.animateFloat(initialValue = 0f, targetValue = -4f, animationSpec = androidx.compose.animation.core.infiniteRepeatable(animation = androidx.compose.animation.core.tween(1100, easing = androidx.compose.animation.core.FastOutSlowInEasing), repeatMode = androidx.compose.animation.core.RepeatMode.Reverse), label = "yuki-bob-offset")
    Image(painter = painterResource(R.drawable.ic_shiba_launcher), contentDescription = "Юки — сиба-ину", modifier = Modifier.size(size.dp).offset(y = bob.dp))
}

@Composable private fun ShibaBadge(size: Int) {
    Box(Modifier.size(size.dp).clip(CircleShape).background(Mint), contentAlignment=Alignment.Center) {
        Image(painter=painterResource(R.drawable.ic_shiba_launcher), contentDescription="Сиба-ину Юки", modifier=Modifier.fillMaxSize().padding(3.dp))
    }
}

@Composable private fun StatPill(icon: String, value: String) { Row(Modifier.clip(RoundedCornerShape(14.dp)).background(Paper).padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { Text(icon, fontSize = 15.sp); Spacer(Modifier.width(4.dp)); Text(value, fontWeight = FontWeight.ExtraBold, color = Ink, fontSize = 13.sp) } }

@Composable private fun LessonNode(lesson: Lesson, number: Int, done: Boolean, unlocked: Boolean, tint: Color, onClick: () -> Unit) {
    val scale by animateFloatAsState(if (done) 1.02f else 1f, label = "nodeScale")
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(if (done) tint.copy(.08f) else Cream).clickable(enabled = unlocked, onClick = onClick).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(43.dp).scale(scale).clip(CircleShape).background(when { done -> tint; unlocked -> tint.copy(.14f); else -> Line }), contentAlignment = Alignment.Center) {
            if (done) Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.size(23.dp)) else if (!unlocked) Icon(Icons.Filled.Lock, null, tint = Muted, modifier = Modifier.size(19.dp)) else Text(number.toString(), color = tint, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
        }
        Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(lesson.title, fontWeight = FontWeight.Bold, color = if (unlocked) Ink else Muted, fontSize = 15.sp); Text(lesson.subtitle, fontSize = 11.sp, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis) }
        Text(if (done) "Пройдено" else if (unlocked) "+${lesson.xp} XP" else "Закрыт", color = if (done) tint else Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable private fun MiniAction(emoji: String, title: String, subtitle: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Row(modifier.clip(RoundedCornerShape(19.dp)).background(Paper).clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(emoji, fontSize = 25.sp); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(title, color = Ink, fontSize = 14.sp, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, fontSize = 10.sp, lineHeight = 13.sp) }; Icon(Icons.Filled.ChevronRight, null, tint = Muted, modifier = Modifier.size(18.dp))
    }
}

@Composable private fun YukiBuddy(mood: String, compact: Boolean = false) {
    val bobTransition = androidx.compose.animation.core.rememberInfiniteTransition(label = "yuki-idle")
    val bob by bobTransition.animateFloat(initialValue = 0f, targetValue = -3.5f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(950, easing = androidx.compose.animation.core.FastOutSlowInEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Reverse), label = "yuki-bob")
    val pop by animateFloatAsState(targetValue = if (mood == "happy") 1.09f else 1f,
        animationSpec = spring(dampingRatio = 0.38f, stiffness = 420f), label = "yuki-reaction-scale")
    val (line, face, tint) = when (mood) {
        "happy" -> Triple("Ура! Отлично получилось! Давай дальше!", "😄", Mint)
        "thinking" -> Triple("Почти! Ошибаться нормально — разберём ответ вместе.", "🤔", Peach)
        "encourage" -> Triple("Не сдавайся! Попробуй вспомнить подсказку.", "🐾", Cream)
        "curious" -> Triple("Хм, что это значит? Проверим твои знания!", "👀", Color(0xFFEAF3FF))
        else -> Triple("Привет! Я Юки. Я помогу тебе выучить японский!", "😊", Color(0xFFEFFFF2))
    }
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp).clip(RoundedCornerShape(20.dp)).background(tint).padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(if (compact) 70.dp else 82.dp).offset(y = bob.dp).scale(pop), contentAlignment = Alignment.Center) {
            Image(painterResource(R.drawable.yuki_3d), contentDescription = "Юки, твой помощник", modifier = Modifier.fillMaxSize())
            Text(face, modifier = Modifier.align(Alignment.TopEnd).offset(x = 3.dp, y = (-2).dp), fontSize = 20.sp)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("Юки", color = GreenDark, fontWeight = FontWeight.Black, fontSize = 15.sp)
            AnimatedContent(targetState = line, transitionSpec = { fadeIn(tween(180)) togetherWith fadeOut(tween(120)) }, label = "yuki-dialogue") { text ->
                Text(text, color = Ink, fontSize = 12.sp, lineHeight = 16.sp)
            }
        }
    }
}

@Composable private fun LessonPage(lesson: Lesson, index: Int, onIndex: (Int) -> Unit, onSpeak: (String) -> Unit, onFeedback: (String) -> Unit, onExit: () -> Unit, onMistake: (QuizItem, String) -> Unit, onFinish: (Int) -> Unit) {
    var phase by remember(lesson.id) { mutableIntStateOf(-1) } // -1: teach new words, 0: quiz, 1: retry mistakes, 2: result
    var retryIndex by remember(lesson.id) { mutableIntStateOf(0) }
    var selected by remember(lesson.id, index, phase, retryIndex) { mutableStateOf<String?>(null) }
    var checked by remember(lesson.id, index, phase, retryIndex) { mutableStateOf(false) }
    var showRomaji by remember(lesson.id) { mutableStateOf(lesson.id <= 30) }
    var showGrammarTip by remember(lesson.id) { mutableStateOf(false) }
    var yukiMood by remember(lesson.id) { mutableStateOf("welcome") }
    val missed = remember(lesson.id) { mutableStateListOf<Pair<QuizItem, String>>() }
    var firstTryCorrect by remember(lesson.id) { mutableIntStateOf(0) }
    var firstTryCount by remember(lesson.id) { mutableIntStateOf(0) }
    val startedAt = remember(lesson.id) { System.currentTimeMillis() }
    var interludeKind by remember(lesson.id) { mutableIntStateOf(0) } // 1 = dialogue, 2 = story
    val themedStory = storyLibrary.firstOrNull { it.chapterId == lesson.chapter }
    val themedDialogue = dialogueLibrary.firstOrNull { it.chapterId == lesson.chapter }
    val storyBeat = themedStory?.beats?.getOrNull((lesson.id + lesson.items.size) % (themedStory.beats.size.coerceAtLeast(1)))
    val dialogueTurn = themedDialogue?.turns?.getOrNull((lesson.id + lesson.chapter) % (themedDialogue.turns.size.coerceAtLeast(1)))
    // Teach the meaning before testing: new words are introduced with Japanese, romaji, Russian meaning and tap-to-hear.
    if (phase == -1) {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFFEFFFF2), Color(0xFFFFF7EA)))).verticalScroll(rememberScrollState()).padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onExit) { Icon(Icons.Filled.Close, "Выйти", tint = Muted) }
                Column { Text("СНАЧАЛА ПОЗНАКОМИМСЯ", color = GreenDark, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp); Text(lesson.title, color = Ink, fontSize = 25.sp, fontWeight = FontWeight.Black) }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().shadow(6.dp, RoundedCornerShape(22.dp)).clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(listOf(Color(0xFF59B97A), Color(0xFF9DDFAD)))).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("Привет! Я Юки! 🐕", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black); Spacer(Modifier.height(4.dp)); Text("Сначала разберём значения и произношение. Потом потренируемся — ничего не нужно угадывать вслепую!", color = Color.White, fontSize = 13.sp, lineHeight = 19.sp) }
                Image(painterResource(R.drawable.yuki_3d), contentDescription = "Юки", modifier = Modifier.size(86.dp))
            }
            Spacer(Modifier.height(15.dp))
            lesson.teachingWords.forEachIndexed { i, word ->
                Column(Modifier.fillMaxWidth().padding(bottom = 10.dp).shadow(3.dp, RoundedCornerShape(20.dp)).clip(RoundedCornerShape(20.dp)).background(Color.White).clickable { onSpeak(word.jp) }.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) { Text("${i + 1}", color = GreenDark, fontSize = 12.sp, fontWeight = FontWeight.Black, modifier = Modifier.clip(CircleShape).background(Mint).padding(horizontal = 10.dp, vertical = 6.dp)); Spacer(Modifier.width(10.dp)); Text(word.jp, color = Ink, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.weight(1f)); Icon(Icons.Filled.VolumeUp, "Послушать", tint = GreenDark) }
                    Spacer(Modifier.height(5.dp)); Text(word.romaji, color = GreenDark, fontSize = 15.sp, fontWeight = FontWeight.Bold); Text("Значение: ${word.ru}", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold); Spacer(Modifier.height(5.dp)); Text("Нажми на карточку, чтобы услышать произношение.", color = Muted, fontSize = 11.sp)
                }
            }
            Button(onClick = { onFeedback("start"); phase = 0; onSpeak(lesson.teachingWords.firstOrNull()?.jp.orEmpty()) }, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(17.dp), colors = ButtonDefaults.buttonColors(containerColor = GreenDark)) { Text("Всё понятно — начать практику", fontWeight = FontWeight.ExtraBold) }
        }
        return
    }
    if (interludeKind != 0) {
        val isDialogue = interludeKind == 1
        val headline = if (isDialogue) "МИНИ-ДИАЛОГ С ЮКИ" else "ИСТОРИЯ ПО ТЕМЕ УРОКА"
        LaunchedEffect(interludeKind, lesson.id) {
            if (isDialogue) dialogueTurn?.let { onSpeak(it.promptJp) } else storyBeat?.let { onSpeak(it.jp) }
        }
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFFEFFFF2), Color(0xFFFFF7EA)))).verticalScroll(rememberScrollState()).padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onExit) { Icon(Icons.Filled.Close, null, tint = Muted) }; Column { Text("УРОК ${lesson.id} · ПАУЗА ДЛЯ ПРАКТИКИ", color = GreenDark, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold); Text(if (isDialogue) "Поговорим!" else "Маленькая история", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Black) } }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(24.dp)).clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(if (isDialogue) listOf(Color(0xFF4C8FCE), Color(0xFF9DCAFF)) else listOf(Color(0xFFEF9C59), Color(0xFFFFD79B)))).padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(headline, color = Color.White.copy(.85f), fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.1.sp); Text(if (isDialogue) themedDialogue?.title ?: "Разговор с Юки" else themedStory?.title ?: "История с Юки", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black); Text("Тема: ${chapters[lesson.chapter-1].title}", color = Color.White.copy(.95f), fontSize = 12.sp) }
                Image(painterResource(R.drawable.yuki_3d), contentDescription = "Юки", modifier = Modifier.size(78.dp))
            }
            Spacer(Modifier.height(14.dp))
            if (isDialogue && dialogueTurn != null) {
                Column(Modifier.fillMaxWidth().shadow(5.dp, RoundedCornerShape(22.dp)).clip(RoundedCornerShape(22.dp)).background(Color.White).padding(17.dp)) {
                    Text("СОБЕСЕДНИК", color = Blue, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp)
                    Text(dialogueTurn.promptJp, color = Ink, fontSize = 25.sp, fontWeight = FontWeight.Bold, lineHeight = 32.sp)
                    Text(dialogueTurn.promptRomaji, color = GreenDark, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(dialogueTurn.promptRu, color = Muted, fontSize = 13.sp)
                    Text("▶ Послушать фразу", Modifier.clickable { onSpeak(dialogueTurn.promptJp) }.padding(top = 9.dp), color = Blue, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(Modifier.height(13.dp)); Divider(color = Line)
                    Text("ЮКИ ОТВЕЧАЕТ", Modifier.padding(top = 12.dp), color = GreenDark, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp)
                    Text(dialogueTurn.replyJp, color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold, lineHeight = 31.sp)
                    Text(dialogueTurn.replyRomaji, color = GreenDark, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(dialogueTurn.replyRu, color = Muted, fontSize = 13.sp)
                    Text("▶ Послушать ответ Юки", Modifier.clickable { onSpeak(dialogueTurn.replyJp) }.padding(top = 9.dp), color = GreenDark, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            } else if (!isDialogue && storyBeat != null) {
                Column(Modifier.fillMaxWidth().shadow(5.dp, RoundedCornerShape(22.dp)).clip(RoundedCornerShape(22.dp)).background(Color.White).padding(17.dp)) {
                    Text(storyBeat.jp, color = Ink, fontSize = 25.sp, fontWeight = FontWeight.Bold, lineHeight = 32.sp)
                    Text(storyBeat.romaji, color = GreenDark, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(storyBeat.translation, color = Muted, fontSize = 14.sp, lineHeight = 20.sp)
                    Text("▶ Послушать историю", Modifier.clickable { onSpeak(storyBeat.jp) }.padding(top = 10.dp), color = GreenDark, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(Modifier.height(13.dp)); Text("Вопрос по истории", color = Ink, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                    Text(storyBeat.question, color = Muted, fontSize = 13.sp)
                    Text("Ответ: ${storyBeat.answer}", color = GreenDark, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            } else {
                Text("Повторим тему вместе с Юки!", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(20.dp))
            Button(onClick = { interludeKind = 0 }, modifier = Modifier.fillMaxWidth().height(55.dp), shape = RoundedCornerShape(17.dp), colors = ButtonDefaults.buttonColors(containerColor = GreenDark)) {
                Text(if (lessonIndex == lesson.items.lastIndex) "Вернуться к уроку" else "Продолжить урок →", fontWeight = FontWeight.ExtraBold)
            }
        }
        return
    }
    val grammarTip = grammarLibrary[(lesson.id - 1).coerceAtLeast(0) % grammarLibrary.size]
    val question = when (phase) { 0 -> lesson.items[index.coerceIn(0, lesson.items.lastIndex)]; 1 -> missed[retryIndex.coerceIn(0, missed.lastIndex)].first; else -> lesson.items.last() }
    val correct = selected == question.answer
    val progress = when (phase) { 0 -> (index + if (checked) 1 else 0).toFloat() / lesson.items.size; 1 -> 0.85f + (retryIndex.toFloat() / missed.size.coerceAtLeast(1)) * .15f; else -> 1f }

    if (phase == 2) {
        val accuracy = if (firstTryCount == 0) 100 else (firstTryCorrect * 100 / firstTryCount)
        val elapsed = ((System.currentTimeMillis() - startedAt) / 1000L).coerceAtLeast(1L)
        val minutes = elapsed / 60; val seconds = elapsed % 60
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(20.dp)); ShibaBadge(104); Spacer(Modifier.height(12.dp)); Text("Урок завершён!", color=Ink, fontSize=28.sp, fontWeight=FontWeight.ExtraBold); Text("Юки гордится твоим прогрессом 🐕", color=Muted, fontSize=14.sp, textAlign=TextAlign.Center)
            Spacer(Modifier.height(25.dp)); Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                ResultStat("🎯", "$accuracy%", "точность", Modifier.weight(1f))
                ResultStat("⏱️", if(minutes>0) "${minutes}м ${seconds}с" else "${seconds}с", "время урока", Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp)); Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                ResultStat("⚡", "${(elapsed / lesson.items.size.coerceAtLeast(1))}с", "в среднем на задание", Modifier.weight(1f))
                ResultStat("🔁", missed.size.toString(), "ошибок на повтор", Modifier.weight(1f))
            }
            Spacer(Modifier.height(22.dp)); Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Paper).padding(17.dp)) {
                Text(if(missed.isEmpty()) "Без ошибок с первой попытки!" else "Ошибки разобраны", color=GreenDark, fontSize=17.sp, fontWeight=FontWeight.ExtraBold)
                Spacer(Modifier.height(5.dp)); Text(if(missed.isEmpty()) "Отличная работа. Можно переходить к следующему уроку." else "Ты повторил ${missed.size} ${if(missed.size==1) "задание" else "заданий"}. Они также сохранены во вкладке «Повторение», чтобы вернуться к ним позже.", color=Muted, fontSize=13.sp, lineHeight=19.sp)
            }
            Spacer(Modifier.height(20.dp)); Button(onClick={ onFeedback("finish"); onFinish(lesson.xp) }, modifier=Modifier.fillMaxWidth().height(54.dp), shape=RoundedCornerShape(17.dp), colors=ButtonDefaults.buttonColors(containerColor=GreenDark)) { Text("Завершить и вернуться к главе", fontWeight=FontWeight.ExtraBold) }
        }
        return
    }

    Column(Modifier.fillMaxSize().background(Cream).padding(horizontal = 20.dp, vertical = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onExit) { Icon(Icons.Filled.Close, "Выйти из урока", tint = Muted) }; Spacer(Modifier.width(7.dp)); Box(Modifier.weight(1f).height(9.dp).clip(CircleShape).background(Line)) { Box(Modifier.fillMaxWidth(progress.coerceIn(.03f,1f)).fillMaxHeight().clip(CircleShape).background(if(phase==1) Orange else Green)) }; Spacer(Modifier.width(12.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Filled.Favorite, null, tint = Color(0xFFEF6A73), modifier = Modifier.size(18.dp)); Text(" 5", color = Ink, fontWeight = FontWeight.Bold) } }
        Spacer(Modifier.height(14.dp)); Text(if(phase==0) "${lesson.title.uppercase()} • ${index+1} ИЗ ${lesson.items.size}" else "ПОВТОРЯЕМ ОШИБКИ • ${retryIndex+1} ИЗ ${missed.size}", color = if(phase==1) Color(0xFFB86B32) else GreenDark, fontSize = 11.sp, letterSpacing = 1.1.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(7.dp)); Text(if(phase==0) lesson.subtitle else "Не торопись: ответь правильно, чтобы закрепить материал.", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        YukiBuddy(mood = if (checked) if (correct) "happy" else "thinking" else yukiMood, compact = true)
        Spacer(Modifier.height(6.dp)); Text(question.prompt, color = Ink, fontSize = 26.sp, lineHeight = 32.sp, fontWeight = FontWeight.ExtraBold)
        val promptReading = question.reading.ifBlank { if (question.prompt.startsWith("Как читается:")) "" else romanize(question.prompt) }
        if(promptReading.isNotBlank() && (lesson.id <= 10 || showRomaji)) Text(promptReading, color=GreenDark, fontSize=15.sp, fontWeight=FontWeight.SemiBold)
        if(lesson.id > 10 && promptReading.isNotBlank() && phase==0) Text(if(showRomaji) "🔤 Скрыть ромадзи" else "🔤 Показать ромадзи", color=GreenDark, fontSize=12.sp, fontWeight=FontWeight.SemiBold, modifier=Modifier.clip(CircleShape).background(Mint).clickable { showRomaji = !showRomaji }.padding(horizontal=10.dp, vertical=6.dp))
        Spacer(Modifier.height(8.dp)); Text(question.hint, color = Muted, fontSize = 14.sp)
        Spacer(Modifier.height(18.dp))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (phase==0 && index == 0) {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Lavender).clickable { showGrammarTip = !showGrammarTip }.padding(13.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) { Text("📘", fontSize = 19.sp); Spacer(Modifier.width(8.dp)); Column(Modifier.weight(1f)) { Text("Грамматика с Юки", color = Color(0xFF6554B8), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold); Text(grammarTip.title + " · нажми, чтобы разобрать", color = Ink, fontSize = 11.sp) }; Text(if (showGrammarTip) "−" else "+", color = Color(0xFF6554B8), fontSize = 21.sp, fontWeight = FontWeight.Bold) }
                    AnimatedVisibility(showGrammarTip) { Column { Spacer(Modifier.height(9.dp)); Text(grammarTip.subtitle, color = Ink, fontSize = 12.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(6.dp)); Text(grammarTip.example, color = Ink, fontSize = 12.sp, lineHeight = 18.sp); Spacer(Modifier.height(6.dp)); Text(grammarTip.explanation, color = Muted, fontSize = 12.sp, lineHeight = 18.sp) } }
                }
            }
            question.choices.forEachIndexed { i, choice ->
                val isPicked = selected == choice; val showRight = checked && choice == question.answer; val showWrong = checked && isPicked && !correct
                val border = when { showRight -> Green; showWrong -> Color(0xFFE66E75); isPicked -> GreenDark; else -> Line }
                val bg = when { showRight -> Mint; showWrong -> Color(0xFFFFE8E8); isPicked -> Mint; else -> Paper }
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(bg).then(if(isPicked||showRight||showWrong) Modifier else Modifier).clickable(enabled = !checked) { selected = choice }.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(28.dp).clip(RoundedCornerShape(9.dp)).background(if (isPicked || showRight) border else Cream), contentAlignment = Alignment.Center) { if (showRight) Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.size(17.dp)) else Text("${'А'+i}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (isPicked) Color.White else Muted) }
                    Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { val choiceReading = romanize(choice); if(choiceReading.isNotBlank() && (lesson.id <= 10 || showRomaji)) Text(choiceReading, color=GreenDark, fontSize=11.sp, fontWeight=FontWeight.SemiBold); Text(choice, color = Ink, fontWeight = if (isPicked || showRight) FontWeight.Bold else FontWeight.Medium, fontSize = 16.sp) }; if (showRight || showWrong) Text(if (showRight) "✓" else "×", color = border, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                }
            }
        }
        AnimatedVisibility(visible = checked) { Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(if (correct) Mint else Peach).padding(14.dp)) { Text(if (correct) "Отлично! 🎉" else "Запомним и повторим", fontWeight = FontWeight.ExtraBold, color = if (correct) GreenDark else Color(0xFF9C5A20), fontSize = 16.sp); Spacer(Modifier.height(4.dp)); Text(question.explain, color = Ink, fontSize = 13.sp, lineHeight=18.sp); Row(verticalAlignment = Alignment.CenterVertically) { Text("Послушать", color = GreenDark, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { onSpeak(question.prompt) }.padding(top = 8.dp)); Icon(Icons.Filled.VolumeUp, null, tint = GreenDark, modifier = Modifier.padding(start = 4.dp, top = 8.dp).size(16.dp)) } } }
        Spacer(Modifier.height(10.dp))
        Button(onClick = {
            if (!checked) {
                checked = true
                yukiMood = if (correct) "happy" else "thinking"
                onFeedback(if (correct) "correct" else "wrong")
                if (phase==0) { firstTryCount++; if(correct) firstTryCorrect++ else { missed.add(question to (selected ?: "")); onMistake(question, selected ?: "") } }
                else if (phase==1 && correct) { /* the saved mistake remains available for later spaced review */ }
            } else if (phase==1 && !correct) { selected = null; checked = false; yukiMood = "encourage" }
            else if (phase==0 && index < lesson.items.lastIndex) {
                yukiMood = "curious"
                val dialogueMark = (lesson.items.size / 3).coerceIn(2, 5)
                val storyMark = ((lesson.items.size * 2) / 3).coerceAtLeast(dialogueMark + 1)
                if (index == dialogueMark) interludeKind = 1
                else if (index == storyMark) interludeKind = 2
                onIndex(index + 1)
            }
            else if (phase==0) { if(missed.isNotEmpty()) { phase=1; retryIndex=0 } else phase=2 }
            else if (phase==1) { if(retryIndex < missed.lastIndex) retryIndex++ else phase=2 }
        }, enabled = checked || selected != null, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(17.dp), colors = ButtonDefaults.buttonColors(containerColor = if (checked && !correct) Orange else GreenDark, disabledContainerColor = Color(0xFFCAD5CC))) {
            Text(if(!checked) "Проверить ответ" else if(phase==1 && !correct) "Попробовать ещё раз" else if(phase==0 && index==lesson.items.lastIndex && missed.isNotEmpty()) "Перейти к повторению" else if(phase==0 && index==lesson.items.lastIndex) "Посмотреть результат" else if(phase==1 && retryIndex==missed.lastIndex) "Посмотреть результат" else "Продолжить", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}

@Composable private fun ResultStat(icon: String, value: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(20.dp)).background(Paper).padding(vertical=17.dp, horizontal=8.dp), horizontalAlignment=Alignment.CenterHorizontally) {
        Text(icon, fontSize=24.sp); Spacer(Modifier.height(5.dp)); Text(value, color=Ink, fontSize=20.sp, fontWeight=FontWeight.ExtraBold); Text(label, color=Muted, fontSize=11.sp, textAlign=TextAlign.Center, lineHeight=14.sp)
    }
}

private val hira = listOf("あ" to "а","い" to "и","う" to "у","え" to "э","お" to "о","か" to "ка","き" to "ки","く" to "ку","け" to "кэ","こ" to "ко","さ" to "са","し" to "си","す" to "су","せ" to "сэ","そ" to "со","た" to "та","ち" to "ти","つ" to "цу","て" to "тэ","と" to "то","な" to "на","に" to "ни","ぬ" to "ну","ね" to "нэ","の" to "но","は" to "ха","ひ" to "хи","ふ" to "фу","へ" to "хэ","ほ" to "хо","ま" to "ма","み" to "ми","む" to "му","め" to "мэ","も" to "мо","や" to "я","ゆ" to "ю","よ" to "ё","ら" to "ра","り" to "ри","る" to "ру","れ" to "рэ","ろ" to "ро","わ" to "ва","を" to "о","ん" to "н")
private val kata = listOf("ア" to "а","イ" to "и","ウ" to "у","エ" to "э","オ" to "о","カ" to "ка","キ" to "ки","ク" to "ку","ケ" to "кэ","コ" to "ко","サ" to "са","シ" to "си","ス" to "су","セ" to "сэ","ソ" to "со","タ" to "та","チ" to "ти","ツ" to "цу","テ" to "тэ","ト" to "то","ナ" to "на","ニ" to "ни","ヌ" to "ну","ネ" to "нэ","ノ" to "но","ハ" to "ха","ヒ" to "хи","フ" to "фу","ヘ" to "хэ","ホ" to "хо","マ" to "ма","ミ" to "ми","ム" to "му","メ" to "мэ","モ" to "мо","ヤ" to "я","ユ" to "ю","ヨ" to "ё","ラ" to "ра","リ" to "ри","ル" to "ру","レ" to "рэ","ロ" to "ро","ワ" to "ва","ヲ" to "о","ン" to "н")

@Composable private fun KanaPage(selected: String, onSelect: (String) -> Unit, onSpeak: (String) -> Unit) {
    val chars = if (selected == "ひらがな") hira else kata
    var practice by remember { mutableStateOf(false) }
    var cardIndex by remember { mutableIntStateOf(0) }
    var reveal by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Text("ОТДЕЛЬНЫЙ МАРШРУТ", color = GreenDark, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp); Text("Японская азбука", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = Ink); Text("Учи знаки в своём темпе — отдельно от уроков.", fontSize = 13.sp, color = Muted)
        Spacer(Modifier.height(18.dp)); Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Line).padding(4.dp)) { listOf("ひらがな","カタカナ").forEach { label -> Box(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(if (selected == label) Paper else Color.Transparent).clickable { onSelect(label); cardIndex = 0; reveal = false }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) { Text(if (label == "ひらがな") "Хирагана" else "Катакана", fontWeight = FontWeight.Bold, color = if (selected == label) GreenDark else Muted) } } }
        Spacer(Modifier.height(16.dp)); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { InfoChip("${chars.size} знаков"); InfoChip("Основной ряд"); InfoChip("Ромадзи") }
        Spacer(Modifier.height(16.dp)); if (practice) {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Paper).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("КАРТОЧКА ${cardIndex+1} ИЗ ${chars.size}", color = Muted, fontWeight = FontWeight.Bold, fontSize = 11.sp); Spacer(Modifier.height(18.dp)); Text(chars[cardIndex].first, fontSize = 76.sp, color = Ink, fontWeight = FontWeight.Medium); if (reveal) Text(chars[cardIndex].second, fontSize = 24.sp, color = GreenDark, fontWeight = FontWeight.Bold) else Text("Вспомни произношение", color = Muted, fontSize = 13.sp); Spacer(Modifier.height(20.dp)); Button(onClick = { reveal = !reveal }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text(if (reveal) "Скрыть ответ" else "Показать ответ") }; Spacer(Modifier.height(8.dp)); OutlinedButton(onClick = { onSpeak(chars[cardIndex].first) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Icon(Icons.Filled.VolumeUp, null); Spacer(Modifier.width(8.dp)); Text("Послушать") }; Spacer(Modifier.height(12.dp)); Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { OutlinedButton(onClick = { cardIndex = (cardIndex - 1 + chars.size) % chars.size; reveal = false }, modifier = Modifier.weight(1f)) { Text("Назад") }; Button(onClick = { cardIndex = (cardIndex + 1) % chars.size; reveal = false }, modifier = Modifier.weight(1f)) { Text("Дальше →") } }
            }; Spacer(Modifier.height(10.dp)); TextButton(onClick = { practice = false }) { Text("Вернуться к таблице") }
        } else {
            Button(onClick = { practice = true; cardIndex = 0; reveal = false }, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(15.dp)) { Text("Начать тренировку карточками", fontWeight = FontWeight.Bold) }
            Spacer(Modifier.height(16.dp)); Text("Знаки и произношение", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.height(10.dp))
            val rows = chars.chunked(5)
            rows.forEach { row -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) { row.forEach { (symbol, reading) -> Column(Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(Paper).clickable { onSpeak(symbol) }.padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(symbol, color = Ink, fontSize = 27.sp); Text(reading, color = GreenDark, fontSize = 11.sp, fontWeight = FontWeight.Bold) } }; repeat(5-row.size) { Spacer(Modifier.weight(1f)) } }; Spacer(Modifier.height(8.dp)) }
            Spacer(Modifier.height(8.dp)); Text("Подсказка: хирагана чаще используется для японских слов и грамматики, катакана — для иностранных слов, например コーヒー (кофе).", color = Muted, fontSize = 12.sp, lineHeight = 18.sp, modifier = Modifier.clip(RoundedCornerShape(16.dp)).background(Paper).padding(14.dp))
        }
        Spacer(Modifier.height(20.dp)); Text("Азбука не смешивается с тематическими уроками — здесь отдельный учебный маршрут.", color = Muted, fontSize = 11.sp)
    }
}

@Composable private fun InfoChip(text: String) { Text(text, Modifier.clip(CircleShape).background(Mint).padding(horizontal = 10.dp, vertical = 7.dp), color = GreenDark, fontSize = 11.sp, fontWeight = FontWeight.Bold) }

private val words: List<Triple<String, String, String>> by lazy {
    allVocabulary.map { Triple(it.jp, it.romaji, it.ru) }.distinctBy { it.first }
}

@Composable private fun WordsPage(onSpeak: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(setOf("こんにちは", "ありがとう", "すみません")) }
    val filtered = words.filter { (jp, romaji, ru) -> listOf(jp, romaji, ru).any { it.contains(query, true) } }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("ТВОЙ СЛОВАРИК", color = GreenDark, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp); Text("Слова", fontSize = 28.sp, color = Ink, fontWeight = FontWeight.ExtraBold); Text("Японский • произношение • перевод", color = Muted, fontSize = 13.sp); Spacer(Modifier.height(15.dp))
        OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Найти слово или перевод…") }, leadingIcon = { Icon(Icons.Filled.Explore, null) }, singleLine = true, shape = RoundedCornerShape(16.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = GreenDark, unfocusedBorderColor = Line))
        Spacer(Modifier.height(12.dp)); Text("${filtered.size} слов", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 20.dp)) { items(filtered) { (jp, romaji, ru) -> Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Paper).padding(13.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(jp, color = Ink, fontSize = 23.sp, fontWeight = FontWeight.Medium); Text(romaji, color = GreenDark, fontSize = 12.sp, fontWeight = FontWeight.Bold); Text(ru, color = Muted, fontSize = 13.sp) }; IconButton(onClick = { onSpeak(jp) }) { Icon(Icons.Filled.VolumeUp, "Послушать", tint = GreenDark) }; Text(if (jp in saved) "★" else "☆", modifier = Modifier.clickable { saved = if (jp in saved) saved - jp else saved + jp }.padding(5.dp), fontSize = 22.sp, color = Orange) } } }
    }
}

@Composable private fun ReviewPage(mistakes: List<ReviewMistake>, onResolve: (String) -> Unit, onSpeak: (String) -> Unit, onBack: () -> Unit) {
    var selected by remember { mutableStateOf<String?>(null) }; var checked by remember { mutableStateOf(false) }
    val item = mistakes.firstOrNull()
    Column(Modifier.fillMaxSize().padding(horizontal=18.dp, vertical=12.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) { IconButton(onClick=onBack) { Icon(Icons.Filled.Close, null, tint=Muted) }; Column(Modifier.weight(1f)) { Text("ЗАКРЕПЛЯЕМ НАВСЕГДА", color=GreenDark, fontSize=10.sp, fontWeight=FontWeight.ExtraBold, letterSpacing=1.2.sp); Text("Мои ошибки", fontSize=26.sp, fontWeight=FontWeight.ExtraBold, color=Ink) }; Surface(color=Peach, shape=RoundedCornerShape(13.dp)) { Text("${mistakes.size}", Modifier.padding(horizontal=12.dp, vertical=7.dp), color=Color(0xFFB86B32), fontWeight=FontWeight.ExtraBold) } }
        Spacer(Modifier.height(6.dp)); Text("Ошибки из уроков сохраняются здесь. Ответь правильно, чтобы убрать задание из списка.", color=Muted, fontSize=12.sp, lineHeight=18.sp)
        if(item==null) {
            Column(Modifier.fillMaxWidth().weight(1f), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) { ShibaBadge(100); Spacer(Modifier.height(15.dp)); Text("Пока всё чисто!", color=Ink, fontSize=23.sp, fontWeight=FontWeight.ExtraBold); Spacer(Modifier.height(6.dp)); Text("Когда ошибёшься в уроке, Юки сохранит задание здесь для дополнительной практики.", color=Muted, fontSize=14.sp, textAlign=TextAlign.Center, lineHeight=21.sp) }
        } else {
            Spacer(Modifier.height(16.dp)); Text("Глава ${item.chapter} · ${item.lessonTitle}", color=GreenDark, fontSize=12.sp, fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(12.dp)); Column(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(24.dp)).background(Paper).padding(18.dp)) {
                Text("ВСПОМНИ ПРАВИЛЬНЫЙ ОТВЕТ", color=Muted, fontSize=10.sp, fontWeight=FontWeight.ExtraBold, letterSpacing=1.1.sp); Spacer(Modifier.height(14.dp)); Text(item.prompt, color=Ink, fontSize=25.sp, lineHeight=31.sp, fontWeight=FontWeight.ExtraBold); Spacer(Modifier.height(7.dp)); Text(item.hint, color=Muted, fontSize=13.sp); if(item.wrongAnswer.isNotBlank()) Text("В прошлый раз: ${item.wrongAnswer}", color=Color(0xFFB86B32), fontSize=11.sp, fontWeight=FontWeight.SemiBold)
                Spacer(Modifier.height(18.dp)); item.choices.forEachIndexed { i, choice ->
                    val picked=selected==choice; val right=checked && choice==item.answer; val wrong=checked && picked && !right
                    Row(Modifier.fillMaxWidth().padding(vertical=4.dp).clip(RoundedCornerShape(15.dp)).background(if(right) Mint else if(wrong) Color(0xFFFFE8E8) else Cream).clickable(enabled=!checked){selected=choice}.padding(13.dp), verticalAlignment=Alignment.CenterVertically) { Box(Modifier.size(28.dp).clip(RoundedCornerShape(9.dp)).background(if(picked||right) if(wrong) Color(0xFFE16E75) else Green else Paper), contentAlignment=Alignment.Center) { Text(if(right) "✓" else "${'А'+i}", color=if(picked||right) Color.White else Muted, fontWeight=FontWeight.Bold) }; Spacer(Modifier.width(10.dp)); Text(choice, Modifier.weight(1f), color=Ink, fontSize=15.sp, fontWeight=if(picked||right) FontWeight.Bold else FontWeight.Medium); if(wrong) Text("×", color=Color(0xFFE16E75), fontSize=20.sp) }
                }
                AnimatedVisibility(checked) { Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(if(selected==item.answer) Mint else Peach).padding(12.dp)) { Text(if(selected==item.answer) "Верно! Ошибка исправлена 🎉" else "Попробуй ещё раз", color=if(selected==item.answer) GreenDark else Color(0xFF9C5A20), fontWeight=FontWeight.ExtraBold); Spacer(Modifier.height(5.dp)); Text(item.explain, color=Ink, fontSize=12.sp, lineHeight=18.sp); Text("Послушать японский", Modifier.clickable { onSpeak(item.prompt) }.padding(top=8.dp), color=GreenDark, fontWeight=FontWeight.Bold, fontSize=12.sp) } }
            }
            Spacer(Modifier.height(12.dp)); Button(onClick={ if(!checked) { if(selected!=null) checked=true } else if(selected==item.answer) { onResolve(item.key); selected=null; checked=false } else { selected=null; checked=false } }, enabled=checked || selected!=null, modifier=Modifier.fillMaxWidth().height(53.dp), shape=RoundedCornerShape(16.dp), colors=ButtonDefaults.buttonColors(containerColor=if(checked && selected!=item.answer) Orange else GreenDark)) { Text(if(!checked) "Проверить ответ" else if(selected==item.answer) "Убрать из списка и дальше" else "Попробовать снова", fontWeight=FontWeight.ExtraBold) }
        }
    }
}

@Composable private fun StoryPage(story: YukiStory, index: Int, onBeat: (Int) -> Unit, onSpeak: (String) -> Unit, onBack: () -> Unit) {
    var selected by remember(story.chapterId, index) { mutableStateOf<String?>(null) }
    var checked by remember(story.chapterId, index) { mutableStateOf(false) }
    var questionVisible by remember(story.chapterId, index) { mutableStateOf(false) }
    val beat = story.beats[index]
    val isCorrect = selected == beat.answer
    LaunchedEffect(story.chapterId, index) { onSpeak(beat.jp) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=18.dp, vertical=12.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) { IconButton(onClick=onBack) { Icon(Icons.Filled.Close, "Назад", tint=Muted) }; Column(Modifier.weight(1f)) { Text("АУДИОИСТОРИЯ С ЮКИ", color=GreenDark, fontSize=10.sp, fontWeight=FontWeight.ExtraBold, letterSpacing=1.3.sp); Text(story.title, color=Ink, fontSize=22.sp, fontWeight=FontWeight.ExtraBold) }; ShibaBadge(50) }
        Spacer(Modifier.height(8.dp)); Text("Юки рассказывает вслух. Текст и перевод скрыты — слушай внимательно, как в настоящем аудировании.", color=Muted, fontSize=12.sp, lineHeight=18.sp)
        Spacer(Modifier.height(14.dp)); Row(horizontalArrangement=Arrangement.spacedBy(5.dp), modifier=Modifier.fillMaxWidth()) { story.beats.forEachIndexed { i, _ -> Box(Modifier.weight(1f).height(6.dp).clip(CircleShape).background(if(i <= index) Green else Line)) } }
        Spacer(Modifier.height(22.dp)); Text("ОСТАНОВКА ${index+1} ИЗ ${story.beats.size}", color=Muted, fontSize=10.sp, fontWeight=FontWeight.ExtraBold, letterSpacing=1.2.sp)
        Spacer(Modifier.height(10.dp)); Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Brush.linearGradient(listOf(Color(0xFF2C8258), Color(0xFF77C990)))).padding(23.dp), horizontalAlignment=Alignment.CenterHorizontally) {
            ShibaBadge(112); Spacer(Modifier.height(12.dp)); Text("Юки рассказывает…", color=Color.White, fontSize=20.sp, fontWeight=FontWeight.ExtraBold); Spacer(Modifier.height(7.dp)); Text("Слушай японский фрагмент и запомни детали.", color=Color.White.copy(.88f), fontSize=13.sp, textAlign=TextAlign.Center, lineHeight=19.sp)
            Spacer(Modifier.height(18.dp)); OutlinedButton(onClick={ onSpeak(beat.jp) }, shape=RoundedCornerShape(15.dp), colors=ButtonDefaults.outlinedButtonColors(contentColor=Color.White), border=BorderStroke(1.dp,Color.White.copy(.7f))) { Icon(Icons.Filled.VolumeUp,null); Spacer(Modifier.width(8.dp)); Text("Прослушать ещё раз", fontWeight=FontWeight.Bold) }
        }
        if (!questionVisible) {
            Spacer(Modifier.height(20.dp)); Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Paper).padding(19.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                Text("🎧", fontSize=34.sp); Spacer(Modifier.height(7.dp)); Text("Слушай внимательно", color=Ink, fontSize=20.sp, fontWeight=FontWeight.ExtraBold); Spacer(Modifier.height(5.dp)); Text("Когда закончишь слушать, открой вопрос. Текст истории не появится даже после ответа.", color=Muted, fontSize=13.sp, lineHeight=19.sp, textAlign=TextAlign.Center)
                Spacer(Modifier.height(14.dp)); Button(onClick={ questionVisible=true }, modifier=Modifier.fillMaxWidth().height(52.dp), shape=RoundedCornerShape(16.dp), colors=ButtonDefaults.buttonColors(containerColor=GreenDark)) { Text("Я прослушал — задать вопрос", fontWeight=FontWeight.ExtraBold) }
            }
        } else {
            Spacer(Modifier.height(22.dp)); Text("Пауза! О чём говорилось?", color=Ink, fontSize=21.sp, fontWeight=FontWeight.ExtraBold); Spacer(Modifier.height(6.dp)); Text(beat.question, color=Muted, fontSize=14.sp)
            Spacer(Modifier.height(12.dp)); beat.choices.forEachIndexed { i, choice ->
                val picked=selected==choice; val right=checked && choice==beat.answer; val wrong=checked && picked && !isCorrect
                val tint=when { right -> Green; wrong -> Color(0xFFE16E75); picked -> GreenDark; else -> Line }
                Row(Modifier.fillMaxWidth().padding(vertical=4.dp).clip(RoundedCornerShape(17.dp)).background(if(right) Mint else if(wrong) Color(0xFFFFE8E8) else Paper).clickable(enabled=!checked){selected=choice}.padding(14.dp), verticalAlignment=Alignment.CenterVertically) { Box(Modifier.size(30.dp).clip(RoundedCornerShape(10.dp)).background(if(picked || right) tint else Cream), contentAlignment=Alignment.Center) { if(right) Icon(Icons.Filled.Check,null,tint=Color.White) else Text("${'А'+i}", color=if(picked) Color.White else Muted, fontWeight=FontWeight.Bold) }; Spacer(Modifier.width(11.dp)); Text(choice, Modifier.weight(1f), color=Ink, fontWeight=if(picked || right) FontWeight.Bold else FontWeight.Medium, fontSize=15.sp); if(right || wrong) Text(if(right) "✓" else "×", color=tint, fontSize=20.sp, fontWeight=FontWeight.ExtraBold) }
            }
            AnimatedVisibility(checked) { Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(if(isCorrect) Mint else Peach).padding(14.dp)) { Text(if(isCorrect) "Верно! Ты уловил смысл 🎉" else "Ничего, послушай ещё раз", color=if(isCorrect) GreenDark else Color(0xFF9C5A20), fontWeight=FontWeight.ExtraBold); Spacer(Modifier.height(5.dp)); Text(beat.explanation, color=Ink, fontSize=13.sp, lineHeight=19.sp) } }
            Spacer(Modifier.height(15.dp)); Button(onClick={ if(!checked) { if(selected!=null) checked=true } else if(index < story.beats.lastIndex) onBeat(index+1) else onBack() }, enabled=checked || selected!=null, modifier=Modifier.fillMaxWidth().height(54.dp), shape=RoundedCornerShape(17.dp), colors=ButtonDefaults.buttonColors(containerColor=GreenDark)) { Text(if(!checked) "Проверить ответ" else if(index<story.beats.lastIndex) "Продолжить аудиоисторию →" else "Завершить историю", fontSize=15.sp, fontWeight=FontWeight.ExtraBold) }
        }
    }
}

@Composable private fun DialoguesPage(chapterId: Int, onBack: () -> Unit, onOpen: (YukiDialogue) -> Unit) {
    val chapter=chapters.first { it.id==chapterId }; val list=dialogueLibrary.filter { it.chapterId==chapterId }
    Column(Modifier.fillMaxSize().padding(horizontal=18.dp, vertical=12.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) { IconButton(onClick=onBack){Icon(Icons.Filled.Close,null,tint=Muted)}; Column(Modifier.weight(1f)){Text("ПРАКТИКА РЕЧИ",color=GreenDark,fontSize=10.sp,fontWeight=FontWeight.ExtraBold,letterSpacing=1.2.sp);Text("Поговори с Юки",color=Ink,fontSize=25.sp,fontWeight=FontWeight.ExtraBold)};ShibaBadge(50) }
        Spacer(Modifier.height(5.dp)); Text("Глава $chapterId · ${chapter.title}",color=Muted,fontSize=13.sp); Spacer(Modifier.height(15.dp)); Text("Выбери ситуацию",color=Ink,fontSize=18.sp,fontWeight=FontWeight.ExtraBold); Spacer(Modifier.height(9.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(11.dp),contentPadding=PaddingValues(bottom=20.dp)) { items(list) { d ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Paper).clickable { onOpen(d) }.padding(16.dp),verticalAlignment=Alignment.CenterVertically) { Box(Modifier.size(53.dp).clip(RoundedCornerShape(17.dp)).background(if(d.id.endsWith("-1")) Mint else Lavender),contentAlignment=Alignment.Center){Text(if(d.id.endsWith("-1")) "💬" else "🎭",fontSize=27.sp)};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(d.title,color=Ink,fontSize=16.sp,fontWeight=FontWeight.ExtraBold);Text(d.subtitle,color=Muted,fontSize=12.sp,lineHeight=17.sp);Spacer(Modifier.height(7.dp));Text("${d.turns.size} реплики · ${if(chapterId<8) "Начальный уровень" else if(chapterId<18) "Средний уровень" else "Продвинутый диалог"}",color=GreenDark,fontSize=10.sp,fontWeight=FontWeight.Bold)};Icon(Icons.Filled.ChevronRight,null,tint=GreenDark)}
        } }
    }
}

@Composable private fun ConversationPage(dialogue: YukiDialogue, index: Int, onTurn: (Int) -> Unit, onSpeak: (String) -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    var selected by remember(dialogue.id,index) { mutableStateOf<String?>(null) }; var checked by remember(dialogue.id,index) { mutableStateOf(false) }; var voiceTranscript by remember(dialogue.id,index) { mutableStateOf("") }; var voiceMessage by remember(dialogue.id,index) { mutableStateOf("") }
    val turn=dialogue.turns[index.coerceIn(0,dialogue.turns.lastIndex)]; val correct=selected==turn.answer
    val speechLauncher = androidx.activity.compose.rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            voiceTranscript = spoken
            val normalized = spoken.replace(Regex("[\\s、。,.!?！？]"), "")
            val matched = turn.choices.firstOrNull { it.jp.replace(Regex("[\\s、。,.!?！？]"), "") == normalized }
            if (matched != null) { selected = matched.jp; voiceMessage = "Речь распознана — проверь выбранный ответ." } else voiceMessage = "Юки не смог уверенно сопоставить фразу. Выбери ответ вручную или попробуй ещё раз."
        } else voiceMessage = "Распознавание отменено. Можно выбрать ответ вручную."
    }
    val permissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ja-JP"); putExtra(RecognizerIntent.EXTRA_PROMPT, "Ответь Юки по-японски") }; runCatching { speechLauncher.launch(intent) }.onFailure { voiceMessage = "На устройстве не найдено приложение для распознавания речи." } }
        else voiceMessage = "Чтобы отвечать голосом, разреши доступ к микрофону в настройках приложения."
    }
    LaunchedEffect(dialogue.id,index) { onSpeak(turn.promptJp) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=18.dp,vertical=12.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick=onBack){Icon(Icons.Filled.Close,null,tint=Muted)};Column(Modifier.weight(1f)){Text("ДИАЛОГ С ЮКИ",color=GreenDark,fontSize=10.sp,fontWeight=FontWeight.ExtraBold,letterSpacing=1.2.sp);Text(dialogue.title,color=Ink,fontSize=22.sp,fontWeight=FontWeight.ExtraBold)};ShibaBadge(46)}
        Spacer(Modifier.height(8.dp));Row(Modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(Line)){Box(Modifier.fillMaxWidth((index+if(checked) 1 else 0).toFloat()/dialogue.turns.size).fillMaxHeight().clip(CircleShape).background(Green))};Spacer(Modifier.height(17.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(Color(0xFF2C8258),Color(0xFF77C990)))).padding(17.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Юки говорит",color=Color.White.copy(.8f),fontSize=11.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(7.dp));Text(turn.promptJp,color=Color.White,fontSize=23.sp,lineHeight=31.sp,fontWeight=FontWeight.Bold);Text(turn.promptRomaji,color=Color.White.copy(.9f),fontSize=13.sp);Spacer(Modifier.height(4.dp));Text(turn.promptRu,color=Color.White,fontSize=15.sp)};IconButton(onClick={onSpeak(turn.promptJp)}){Icon(Icons.Filled.VolumeUp,null,tint=Color.White,modifier=Modifier.size(27.dp))}}
        Spacer(Modifier.height(19.dp));Text(turn.question,color=Ink,fontSize=20.sp,fontWeight=FontWeight.ExtraBold);Spacer(Modifier.height(10.dp))
        OutlinedButton(enabled=!checked, onClick={ if(ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED){ val intent=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ja-JP");putExtra(RecognizerIntent.EXTRA_PROMPT,"Ответь Юки по-японски")};runCatching{speechLauncher.launch(intent)}.onFailure{voiceMessage="На устройстве не найдено приложение для распознавания речи."} } else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO) }, modifier=Modifier.fillMaxWidth(), shape=RoundedCornerShape(15.dp), border=BorderStroke(1.dp,Green.copy(.55f)), colors=ButtonDefaults.outlinedButtonColors(contentColor=GreenDark)) { Icon(Icons.Filled.Mic,null);Spacer(Modifier.width(8.dp));Text("Ответить голосом",fontWeight=FontWeight.Bold) }
        if(voiceTranscript.isNotBlank()) Text("Распознано: $voiceTranscript",Modifier.fillMaxWidth().padding(top=5.dp),color=Ink,fontSize=12.sp)
        if(voiceMessage.isNotBlank()) Text(voiceMessage,Modifier.fillMaxWidth().padding(top=3.dp),color=Muted,fontSize=11.sp,lineHeight=16.sp)
        Spacer(Modifier.height(8.dp));turn.choices.forEachIndexed { i,c -> val picked=selected==c.jp;val right=checked&&c.jp==turn.answer;val wrong=checked&&picked&&!correct
            Row(Modifier.fillMaxWidth().padding(vertical=4.dp).clip(RoundedCornerShape(17.dp)).background(if(right) Mint else if(wrong) Color(0xFFFFE8E8) else Paper).clickable(enabled=!checked){selected=c.jp}.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(29.dp).clip(RoundedCornerShape(9.dp)).background(if(picked||right) if(wrong) Color(0xFFE16E75) else Green else Cream),contentAlignment=Alignment.Center){Text(if(right) "✓" else "${'А'+i}",color=if(picked||right) Color.White else Muted,fontWeight=FontWeight.Bold)};Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(c.jp,color=Ink,fontSize=17.sp,fontWeight=FontWeight.Bold);Text(c.romaji,color=GreenDark,fontSize=11.sp,fontWeight=FontWeight.SemiBold);Text(c.ru,color=Muted,fontSize=12.sp)};if(right||wrong)Text(if(right) "✓" else "×",color=if(right) Green else Color(0xFFE16E75),fontSize=20.sp,fontWeight=FontWeight.ExtraBold)}
        }
        AnimatedVisibility(checked){Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(if(correct) Mint else Peach).padding(14.dp)){Text(if(correct) "Юки: ${turn.replyJp}" else "Не совсем — попробуй ещё раз",color=if(correct) GreenDark else Color(0xFF9C5A20),fontSize=16.sp,fontWeight=FontWeight.ExtraBold);if(correct){Text(turn.replyRomaji,color=GreenDark,fontSize=12.sp);Text(turn.replyRu,color=Ink,fontSize=13.sp);Text("▶ Послушать ответ Юки",Modifier.clickable{onSpeak(turn.replyJp)}.padding(top=7.dp),color=GreenDark,fontWeight=FontWeight.Bold,fontSize=12.sp)}}}
        Spacer(Modifier.height(13.dp));Button(onClick={if(!checked){checked=true;}else if(!correct){selected=null;checked=false}else if(index<dialogue.turns.lastIndex)onTurn(index+1) else onBack()},enabled=checked||selected!=null,modifier=Modifier.fillMaxWidth().height(53.dp),shape=RoundedCornerShape(16.dp),colors=ButtonDefaults.buttonColors(containerColor=if(checked&&!correct) Orange else GreenDark)){Text(if(!checked) "Ответить" else if(!correct) "Попробовать ещё раз" else if(index<dialogue.turns.lastIndex) "Продолжить разговор →" else "Завершить разговор",fontWeight=FontWeight.ExtraBold)}
        Spacer(Modifier.height(7.dp));Text("Реплика ${index+1} из ${dialogue.turns.size} · сложность растёт вместе с курсом",Modifier.fillMaxWidth(),color=Muted,fontSize=11.sp,textAlign=TextAlign.Center)
    }
}

@Composable private fun GrammarPage(onBack: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var expanded by remember { mutableIntStateOf(0) }
    val filtered = grammarLibrary.filter { listOf(it.title,it.subtitle,it.example,it.explanation).any { part -> part.contains(query,true) } }
    Column(Modifier.fillMaxSize().padding(horizontal=17.dp, vertical=12.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) { IconButton(onClick=onBack) { Icon(Icons.Filled.Close, null, tint=Muted) }; Column { Text("ПОНЯТНАЯ ЯПОНСКАЯ", color=GreenDark, fontSize=10.sp, fontWeight=FontWeight.ExtraBold, letterSpacing=1.3.sp); Text("Грамматика", fontSize=27.sp, fontWeight=FontWeight.ExtraBold, color=Ink) } }
        Text("Правило → пример → объяснение по-русски. Возвращайся сюда по мере прохождения уроков.", color=Muted, fontSize=12.sp, lineHeight=18.sp); Spacer(Modifier.height(12.dp))
        OutlinedTextField(value=query,onValueChange={query=it},modifier=Modifier.fillMaxWidth(),singleLine=true,placeholder={Text("Найти частицу или правило…")},shape=RoundedCornerShape(16.dp),colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=GreenDark,unfocusedBorderColor=Line))
        Spacer(Modifier.height(10.dp)); Text("${filtered.size} правил · от основ до A2/B1", color=Muted, fontSize=11.sp, fontWeight=FontWeight.Bold)
        LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp),contentPadding=PaddingValues(bottom=20.dp)) { items(filtered) { rule -> val idx=grammarLibrary.indexOf(rule); val open=expanded==idx
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(19.dp)).background(Paper).clickable { expanded=if(open) -1 else idx }.padding(15.dp)) {
                Row(verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(rule.title,color=GreenDark,fontSize=16.sp,fontWeight=FontWeight.ExtraBold); Text(rule.subtitle,color=Muted,fontSize=12.sp,lineHeight=17.sp) }; Text(if(open) "−" else "+",color=GreenDark,fontSize=23.sp,fontWeight=FontWeight.Bold) }
                AnimatedVisibility(open) { Column { Spacer(Modifier.height(11.dp)); Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(Cream).padding(12.dp)) { Text(rule.example,color=Ink,fontSize=14.sp,lineHeight=22.sp) }; Spacer(Modifier.height(9.dp)); Text(rule.explanation,color=Ink,fontSize=13.sp,lineHeight=20.sp) } }
            }
        } }
    }
}

@Composable private fun ProfilePage(xp: Int, done: Int, streak: Int, onSpeak: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(15.dp)); Box(Modifier.size(112.dp).clip(CircleShape).background(Mint), contentAlignment = Alignment.Center) { Image(painter = painterResource(R.drawable.ic_shiba_launcher), contentDescription = "Юки — сиба-ину", modifier = Modifier.fillMaxSize().padding(4.dp)) }; Spacer(Modifier.height(12.dp)); Text("Твой профиль", fontSize = 27.sp, color = Ink, fontWeight = FontWeight.ExtraBold); Text("Учись в своём ритме вместе с Юки", color = Muted, fontSize = 13.sp); Spacer(Modifier.height(22.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { ProfileStat("⚡", xp.toString(), "опыта"); ProfileStat("📚", done.toString(), "уроков"); ProfileStat("🔥", streak.toString(), "дней подряд") }
        Spacer(Modifier.height(22.dp)); Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Paper).padding(18.dp)) { Text("Твои достижения", color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp); Spacer(Modifier.height(13.dp)); Achievement("🌱", "Первый росток", "Заверши первый урок", done >= 1); Achievement("📖", "Уже читатель", "Пройди 5 уроков", done >= 5); Achievement("🏆", "Первые главы", "Пройди 10 уроков", done >= 10); Achievement("🐕", "Юки подрос", "Пройди 25 уроков", done >= 25); Achievement("🌟", "Друг Юки", "Пройди 100 уроков", done >= 100) }
        Spacer(Modifier.height(14.dp)); Button(onClick = { onSpeak("こんにちは。ユキです。よろしくね！") }, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(17.dp), colors = ButtonDefaults.buttonColors(containerColor = GreenDark)) { Icon(Icons.Filled.VolumeUp, null); Spacer(Modifier.width(8.dp)); Text("Проверить японскую озвучку", fontWeight = FontWeight.ExtraBold) }
        Text("Если голоса нет, приложение предложит установить японские голосовые данные Android.", Modifier.fillMaxWidth().padding(top = 7.dp), color = Muted, fontSize = 11.sp, lineHeight = 16.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(20.dp)); Text("SHIBA YUKI", color = GreenDark, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp); Text("Разработчик: Twiksi", color = Muted, fontSize = 12.sp); Text("Версия 4.3 • Учим японский с Юки", color = Muted, fontSize = 11.sp)
    }
}
@Composable private fun ProfileStat(icon: String, number: String, caption: String) { Column(Modifier.width(95.dp).clip(RoundedCornerShape(18.dp)).background(Paper).padding(vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(icon, fontSize = 23.sp); Text(number, color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp); Text(caption, color = Muted, fontSize = 10.sp, textAlign = TextAlign.Center) } }
@Composable private fun Achievement(icon: String, title: String, subtitle: String, unlocked: Boolean) { Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(43.dp).clip(RoundedCornerShape(14.dp)).background(if (unlocked) Peach else Cream), contentAlignment = Alignment.Center) { Text(if (unlocked) icon else "🔒", fontSize = 21.sp) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(title, color = if (unlocked) Ink else Muted, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, fontSize = 11.sp) }; if (unlocked) Icon(Icons.Filled.Check, null, tint = Green) } }
