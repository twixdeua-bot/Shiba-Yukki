package com.nexo.kotoba

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.rotate
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.foundation.clickable
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.delay
import kotlin.random.Random
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import io.github.sceneview.SceneView
import io.github.sceneview.node.ModelNode
import io.github.sceneview.rememberModelInstance

/**
 * Interactive 3D companion viewport. The bundled GLB now contains a named bone hierarchy
 * and independent animation clips (Idle_Breathing, Walk, Run, Sit, Happy, Curious,
 * LieDown, Stretch, GivePaw, Jump, Spin). Body parts are separate meshes parented to
 * their corresponding bones so limbs, ears and tail can move independently. SceneView
 * auto-plays the default idle clip; mood-specific viewport reactions remain layered on top.
 */
@Composable
internal fun Yuki3DView(
    modifier: Modifier = Modifier,
    mood: String = "idle",
    onPet: (() -> Unit)? = null
) {
    var idleBeat by androidx.compose.runtime.remember { androidx.compose.runtime.mutableIntStateOf(0) }
    LaunchedEffect(mood) {
        idleBeat = 0
        while (true) {
            delay(if (mood == "happy" || mood == "run") 420L else 1700L)
            idleBeat = (idleBeat + 1) % 4
        }
    }
    val transition = rememberInfiniteTransition(label = "yuki-personality")
    val bobTarget = when (mood) { "happy" -> 8f; "run" -> 5f; "sad" -> .5f; "sleep" -> .8f; else -> 2f }
    val bob by transition.animateFloat(
        initialValue = if (mood == "sleep") 0f else -bobTarget,
        targetValue = bobTarget,
        animationSpec = infiniteRepeatable(
            tween(if (mood == "happy" || mood == "run") 250 else if (mood == "sleep") 2400 else 1150),
            RepeatMode.Reverse),
        label = "yuki-breath-bob"
    )
    val tiltRange = when (mood) { "curious", "thinking" -> 10f; "happy" -> 5f; "sad" -> 3f; else -> 2f }
    val tilt by transition.animateFloat(
        initialValue = -tiltRange, targetValue = tiltRange,
        animationSpec = infiniteRepeatable(tween(if (mood == "curious" || mood == "thinking") 720 else 1500), RepeatMode.Reverse),
        label = "yuki-head-curiosity"
    )
    val squash by transition.animateFloat(
        initialValue = 1f, targetValue = if (mood == "happy" || mood == "run") 1.06f else .99f,
        animationSpec = infiniteRepeatable(tween(if (mood == "happy" || mood == "run") 260 else 1000), RepeatMode.Reverse),
        label = "yuki-motion-squash"
    )
    Box(
        modifier.offset(y = bob.dp).rotate(tilt).scale(squash)
            .then(if (onPet != null) Modifier.pointerInput(onPet) { detectTapGestures(onTap = { onPet() }) } else Modifier),
        contentAlignment = androidx.compose.ui.Alignment.Center
    ) {
        SceneView(modifier = Modifier.fillMaxSize()) {
            rememberModelInstance(modelLoader, "models/yuki.glb")?.let { instance ->
                ModelNode(
                    modelInstance = instance,
                    scaleToUnits = 2.3f,
                    autoAnimate = true,
                    animationName = when (mood) {
                        "run" -> "Run"
                        "happy" -> "Happy"
                        "curious", "thinking" -> "Curious"
                        "sleep", "sad" -> "LieDown"
                        else -> "Idle_Breathing"
                    },
                    animationLoop = true,
                    animationSpeed = if (mood == "run") 1.25f else 1.0f
                )
            }
        }
        // Tiny visual sparkle on active reactions, independent of network or external assets.
        if (mood == "happy" && idleBeat % 2 == 0) {
            androidx.compose.material3.Text("✦", modifier = Modifier.align(androidx.compose.ui.Alignment.TopEnd), color = Color(0xFFFFC857))
        }
    }
}

internal enum class LessonLocation { CITY, HOSPITAL, PARK, HOME, SHOP, CAFE, SCHOOL, STATION, NATURE, GENERIC }

internal fun locationForChapter(chapter: Int, title: String = ""): LessonLocation {
    val t = title.lowercase()
    return when {
        listOf("больниц", "врач", "здоров", "аптек").any(t::contains) -> LessonLocation.HOSPITAL
        listOf("город", "улиц", "направлен", "адрес", "места", "достопримечательност").any(t::contains) -> LessonLocation.CITY
        listOf("парк", "природ", "погода", "животн").any(t::contains) -> LessonLocation.PARK
        listOf("дом", "комнат", "жиль", "быт").any(t::contains) -> LessonLocation.HOME
        listOf("магазин", "покуп", "одежд", "супермаркет").any(t::contains) -> LessonLocation.SHOP
        listOf("ресторан", "кафе", "еда", "продукт", "напит").any(t::contains) -> LessonLocation.CAFE
        listOf("школ", "учёб", "учеб", "язык", "грамматик", "азбук").any(t::contains) -> LessonLocation.SCHOOL
        listOf("вокзал", "транспорт", "путешеств", "поезд", "аэропорт").any(t::contains) -> LessonLocation.STATION
        chapter in 1..2 -> LessonLocation.PARK
        chapter in 3..6 -> LessonLocation.CITY
        chapter in 7..8 -> LessonLocation.HOME
        chapter == 9 -> LessonLocation.CAFE
        chapter in 10..12 -> LessonLocation.CITY
        chapter in 13..16 -> LessonLocation.SHOP
        chapter in 17..20 -> LessonLocation.STATION
        else -> LessonLocation.GENERIC
    }
}

/** Soft illustrated environment that changes with the lesson topic. */
@Composable
internal fun LessonWorld(location: LessonLocation, modifier: Modifier = Modifier) {
    val sky = when (location) {
        LessonLocation.CITY, LessonLocation.STATION -> listOf(Color(0xFFBFE5F5), Color(0xFFF3F7F3))
        LessonLocation.HOSPITAL -> listOf(Color(0xFFC8F0EA), Color(0xFFF7FFFC))
        LessonLocation.PARK, LessonLocation.NATURE -> listOf(Color(0xFFBDEBD0), Color(0xFFFFF5D9))
        LessonLocation.HOME -> listOf(Color(0xFFFFDCC0), Color(0xFFFFF6E8))
        LessonLocation.SHOP, LessonLocation.CAFE -> listOf(Color(0xFFFFD9BD), Color(0xFFFFF5E9))
        LessonLocation.SCHOOL -> listOf(Color(0xFFD9D2FF), Color(0xFFFFF8E9))
        else -> listOf(Color(0xFFE4F5E9), Color(0xFFFFF7E8))
    }
    Canvas(modifier = modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(24.dp))) {
        drawRect(brush = Brush.verticalGradient(sky))
        // soft sun and clouds
        drawCircle(Color(0xFFFFF0B5), size.minDimension * .085f, Offset(size.width * .83f, size.height * .20f))
        for (i in 0..2) drawCircle(Color.White.copy(alpha=.75f), size.minDimension*.045f, Offset(size.width*(.13f+i*.035f), size.height*(.20f+(i%2)*.02f)))
        when (location) {
            LessonLocation.CITY, LessonLocation.STATION, LessonLocation.HOSPITAL, LessonLocation.SHOP, LessonLocation.SCHOOL -> {
                val colors = listOf(Color(0xFFB3CBD8), Color(0xFF91B7C6), Color(0xFFD5B9A7), Color(0xFFA7C7B6))
                val widths = listOf(.14f,.19f,.13f,.17f,.16f)
                var x = -size.width*.01f
                widths.forEachIndexed { i, w ->
                    val h = size.height*(.35f + (i%3)*.12f)
                    drawRoundRect(colors[i%colors.size], Offset(x,size.height*.55f-h), Size(size.width*w,h), androidx.compose.ui.geometry.CornerRadius(10f))
                    for (row in 0..2) for (col in 0..1) drawRoundRect(Color(0xFFFFF0C8).copy(alpha=.85f), Offset(x+size.width*w*(.18f+col*.42f),size.height*.58f-h+size.height*.06f+row*size.height*.075f), Size(size.width*w*.13f,size.height*.045f), androidx.compose.ui.geometry.CornerRadius(3f))
                    x += size.width*(w*.82f)
                }
                if (location == LessonLocation.HOSPITAL) {
                    drawRoundRect(Color.White, Offset(size.width*.38f,size.height*.43f), Size(size.width*.24f,size.height*.30f), androidx.compose.ui.geometry.CornerRadius(12f))
                    drawRect(Color(0xFF54BBAA), Offset(size.width*.48f,size.height*.48f), Size(size.width*.04f,size.height*.17f))
                    drawRect(Color(0xFF54BBAA), Offset(size.width*.43f,size.height*.545f), Size(size.width*.14f,size.height*.04f))
                    drawRoundRect(Color(0xFF4BAE9C), Offset(size.width*.42f,size.height*.76f), Size(size.width*.16f,size.height*.07f), androidx.compose.ui.geometry.CornerRadius(5f))
                }
                if (location == LessonLocation.SHOP) {
                    drawRoundRect(Color(0xFFFFB85C), Offset(size.width*.20f,size.height*.48f), Size(size.width*.22f,size.height*.11f), androidx.compose.ui.geometry.CornerRadius(8f))
                    drawRoundRect(Color(0xFF7CB8D4), Offset(size.width*.24f,size.height*.61f), Size(size.width*.14f,size.height*.13f), androidx.compose.ui.geometry.CornerRadius(5f))
                }
                if (location == LessonLocation.SCHOOL) {
                    drawRoundRect(Color(0xFF7869B7), Offset(size.width*.39f,size.height*.40f), Size(size.width*.22f,size.height*.12f), androidx.compose.ui.geometry.CornerRadius(6f))
                    drawCircle(Color(0xFFFFD166), size.height*.025f, Offset(size.width*.50f,size.height*.46f))
                }
                drawRect(Color(0xFF9CCDA7), Offset(0f,size.height*.80f), Size(size.width,size.height*.2f))
                drawRoundRect(Color(0xFFB8C8C8), Offset(0f,size.height*.88f), Size(size.width,size.height*.12f), androidx.compose.ui.geometry.CornerRadius(12f))
            }
            LessonLocation.PARK, LessonLocation.NATURE -> {
                drawOval(Color(0xFF93D19A), Offset(0f,size.height*.54f), Size(size.width,size.height*.55f))
                for (i in 0..5) {
                    val x=size.width*(.08f+i*.17f); val y=size.height*(.54f+(i%2)*.07f)
                    drawRoundRect(Color(0xFF9A704C), Offset(x-size.width*.012f,y), Size(size.width*.025f,size.height*.20f), androidx.compose.ui.geometry.CornerRadius(8f))
                    drawCircle(listOf(Color(0xFF64B97B),Color(0xFF79C989),Color(0xFF4CA96B))[i%3],size.height*.13f,Offset(x,y-size.height*.015f))
                }
                drawRoundRect(Color(0xFFE7D6B5), Offset(size.width*.36f,size.height*.78f), Size(size.width*.32f,size.height*.22f), androidx.compose.ui.geometry.CornerRadius(20f))
                // A little pond and flower dots make the park read as a place, not just a green backdrop.
                drawOval(Color(0xFF8ED7E7), Offset(size.width*.70f,size.height*.76f), Size(size.width*.18f,size.height*.09f))
                for (i in 0..4) drawCircle(listOf(Color(0xFFFFA9C8),Color(0xFFFFD166),Color.White)[i%3], size.height*.018f, Offset(size.width*(.12f+i*.055f),size.height*(.80f+(i%2)*.035f)))
            }
            LessonLocation.HOME, LessonLocation.CAFE -> {
                drawRect(Color(0xFFFFEBD8), Offset(0f,size.height*.48f), Size(size.width,size.height*.52f))
                drawRoundRect(if(location==LessonLocation.CAFE) Color(0xFFBD7756) else Color(0xFFCE9A73), Offset(size.width*.13f,size.height*.55f), Size(size.width*.74f,size.height*.28f), androidx.compose.ui.geometry.CornerRadius(18f))
                drawRoundRect(Color(0xFF8F6049), Offset(size.width*.18f,size.height*.79f), Size(size.width*.64f,size.height*.07f), androidx.compose.ui.geometry.CornerRadius(8f))
                drawRoundRect(Color(0xFFB7E3ED), Offset(size.width*.68f,size.height*.12f), Size(size.width*.19f,size.height*.25f), androidx.compose.ui.geometry.CornerRadius(10f))
                drawRect(Color.White, Offset(size.width*.765f,size.height*.12f), Size(size.width*.018f,size.height*.25f)); drawRect(Color.White, Offset(size.width*.68f,size.height*.23f), Size(size.width*.19f,size.height*.018f))
            }
            else -> {
                drawOval(Color(0xFFB6DDB7), Offset(-size.width*.1f,size.height*.57f), Size(size.width*1.2f,size.height*.5f))
                drawRoundRect(Color(0xFFE6D4B7), Offset(size.width*.43f,size.height*.65f), Size(size.width*.14f,size.height*.35f), androidx.compose.ui.geometry.CornerRadius(20f))
            }
        }
    }
}
