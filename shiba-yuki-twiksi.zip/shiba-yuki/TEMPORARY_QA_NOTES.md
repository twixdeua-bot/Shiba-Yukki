# Shiba Yuki — temporary QA shortcuts and rig notes

## Temporary UI — remove before public release
The main learning path has a yellow `ТЕСТ` strip with two shortcuts:
- `Проверить диалог` opens the dialogue list for chapter 1 directly.
- `Проверить историю` opens the chapter 1 story directly.

These are developer-only QA controls. They do not count as progress and do not unlock chapters. Remove them before any public/release build.

## Yuki rig — current implementation
`app/src/main/assets/models/yuki.glb` has been replaced with a locally generated glTF 2.0 character asset containing a named transform/bone hierarchy and 11 animation clips:
`Idle_Breathing`, `Walk`, `Run`, `Sit`, `Happy`, `Curious`, `LieDown`, `Stretch`, `GivePaw`, `Jump`, `Spin`.

The rig uses independently parented mesh parts for the torso, head, ears, four legs, knee/lower-leg and paw segments, plus a three-part tail. Animation channels target those bones, so limbs/ears/tail can move separately. It is a hierarchical rigid-part rig, **not yet a continuous skinned mesh with vertex weights**; joints may show seams during extreme poses. The current SceneView setup auto-plays the default animation. Mood-to-clip switching should be wired to the SceneView animator API and verified on-device in a follow-up pass.

This asset was generated in the available environment without Blender. GLB container and JSON structure were checked locally, but a successful Android APK build and visual/on-device playback have not yet been verified. Do not claim those checks have passed until tested.
