# Backwards-compatible entry point for the updated content validator.
from verify_content import *  # noqa: F401,F403
