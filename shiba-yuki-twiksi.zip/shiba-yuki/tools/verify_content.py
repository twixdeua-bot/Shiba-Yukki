import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
assets = root / "app/src/main/assets"
load = lambda name: json.loads((assets / name).read_text(encoding="utf-8"))
curriculum = load("curriculum.json")
stories = load("stories.json")
dialogues = load("dialogues.json")
grammar = load("grammar.json")
assert len(curriculum) == 26, f"Expected 26 chapters, got {len(curriculum)}"
assert all(len(ch.get("lessons", [])) >= 10 for ch in curriculum), "A chapter has fewer than 10 lessons"
assert len(stories) >= len(curriculum), "Some chapters have no listening story"
assert {s["chapterId"] for s in stories} >= {c["id"] for c in curriculum}, "A chapter is missing a story"
assert all(len(s.get("beats", [])) >= 3 for s in stories), "A story has fewer than three listening stops"
assert len(dialogues) >= len(curriculum) * 2, "Expected two dialogues per chapter"
assert all(len(d.get("turns", [])) >= 3 for d in dialogues), "A dialogue has fewer than three turns"
for d in dialogues:
    for t in d["turns"]:
        options = [c["jp"] for c in t["choices"]]
        assert t["answer"] in options, f"Correct answer missing from {d['id']}"
        assert len(options) >= 3, f"Fewer than three options in {d['id']}"
for story in stories:
    for beat in story["beats"]:
        assert beat["answer"] in beat["choices"], f"Story answer missing in chapter {story['chapterId']}"
print(f"PASS: {len(curriculum)} chapters, {sum(len(c['lessons']) for c in curriculum)} lessons, {len(stories)} stories, {sum(len(s['beats']) for s in stories)} story stops, {len(dialogues)} dialogues, {sum(len(d['turns']) for d in dialogues)} dialogue turns, {len(grammar)} grammar rules")
